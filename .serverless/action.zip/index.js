(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./index.js":
/*!******************!*\
  !*** ./index.js ***!
  \******************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\nconst { downloadStream, uploadStream, transferStream } = __webpack_require__(/*! ./lib/stream */ \"./lib/stream.js\");\nconst { downloadFile, uploadFile } = __webpack_require__(/*! ./lib/file */ \"./lib/file.js\");\nconst { uploadAEMMultipartFile } = __webpack_require__(/*! ./lib/aemmultipart */ \"./lib/aemmultipart.js\");\nconst { getResourceHeaders } = __webpack_require__(/*! ./lib/headers */ \"./lib/headers.js\");\n\nmodule.exports = {\n    downloadStream, uploadStream, transferStream,\n    downloadFile, uploadFile,\n    uploadAEMMultipartFile,\n    getResourceHeaders\n}\n\n\n//# sourceURL=./index.js");

/***/ }),

/***/ "./lib/aemmultipart.js":
/*!*****************************!*\
  !*** ./lib/aemmultipart.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\nconst fs = __webpack_require__(/*! fs */ \"fs\").promises;\nconst { uploadFile } = __webpack_require__(/*! ./file */ \"./lib/file.js\");\nconst filterObject = __webpack_require__(/*! filter-obj */ \"./node_modules/filter-obj/index.js\");\n\n/**\n * @typedef {Object} UploadAEMMultipartOptions\n * \n * @property {String} [method] Optional HTTP method (defaults to 'PUT')\n * @property {Number} [timeout] Optional socket timeout\n * @property {Object} [headers] Optional override of request headers\n * @property {Number} [partSize] Optional custom preferred part size. Might be adjusted depending on the target.\n * @property {Number} [retryMax=60000] time to retry until throwing an error (ms)\n * @property {Number} [retryInterval=100] time between retries, used by exponential backoff (ms)\n * @property {Boolean} [retryEnabled=true] retry on failure enabled\n * @property {Boolean} [retryAllErrors=false] whether or not to retry on all http error codes or just >=500\n */\n/**\n * @typedef {Object} UploadAEMMultipartTarget\n * \n * @property {String[]} urls URLs \n * @property {Number} [minPartSize] Minimum size of each part\n * @property {Number} [maxPartSize] Maximum size of each part \n */\n/**\n * Upload a file in multiple parts to a set of URLs.\n * Intended to be used with AEM/Oak, see for more information:\n * http://jackrabbit.apache.org/oak/docs/apidocs/org/apache/jackrabbit/api/binary/BinaryUpload.html\n * \n * @param {String} filepath Source file path\n * @param {UploadAEMMultipartTarget} target Target urls\n * @param {UploadAEMMultipartOptions} [options] Upload options\n * @returns {Promise} resolves when upload completes\n */\nasync function uploadAEMMultipartFile(filepath, target, options) {\n    if (!target) {\n        throw Error('target not provided');\n    } else if (!target.urls || target.urls.length === 0) {\n        throw Error('invalid number of target urls');\n    } else if (target.minPartSize && target.maxPartSize && (target.minPartSize > target.maxPartSize)) {\n        throw Error(`minPartSize (${target.minPartSize}) > maxPartSize: (${target.maxPartSize})`);\n    }\n\n    // Calculate the partSize based on the number of urls\n    const { size } = await fs.stat(filepath);\n    let partSize = Math.ceil(size / target.urls.length);\n\n    // Make sure that the file is not too large\n    if (target.maxPartSize && (partSize > target.maxPartSize)) {\n        throw Error(`File '${filepath}' is too large to upload: ${size} bytes, maxPartSize: ${target.maxPartSize} bytes, numUploadURIs: ${target.urls.length}`);\n    }\n    \n    // Limit the lower bound to the minPartSize, since the estimated file size to generate uris\n    // may be significantly larger than the actual file size. Also make sure that partSize is positive.\n    partSize = Math.max(\n        partSize,\n        target.minPartSize || 1, \n        1\n    );\n\n    // Override using the user provided partSize, clamp its value to ensure that its at least \n    // the minimum calculated (otherwise there are not enough urls or the blocks are too small).\n    if (options && options.partSize) {\n        partSize = Math.max(partSize, options.partSize);\n        partSize = (target.maxPartSize && Math.min(partSize, target.maxPartSize)) || partSize;\n    }\n\n    // extract upload options\n    const uploadOptions = filterObject(\n        options || {},\n        [ 'method', 'timeout', 'headers',\n          'retryMax', 'retryInterval', 'retryEnabled', 'retryAllErrors' ]\n    );\n \n    // upload blocks\n    // rely on retry functionality in uploadFile\n    let i = 0;\n    let start = 0;\n    while (start < size) {\n        // uploadFile expects an inclusive start and end which is why the -1 is required\n        const length = Math.min(size - start, partSize);\n        await uploadFile(\n            filepath,\n            target.urls[i],\n            Object.assign({}, uploadOptions, {\n                start,\n                end: start + length - 1\n            })\n        );\n        start += length;\n        ++i;\n    }\n}\n\nmodule.exports = {\n    uploadAEMMultipartFile\n}\n\n\n//# sourceURL=./lib/aemmultipart.js");

/***/ }),

/***/ "./lib/error.js":
/*!**********************!*\
  !*** ./lib/error.js ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\nclass HttpResponseError extends Error {\n    constructor(method, url, status, errorResponse) {\n        if (errorResponse) {\n            super(`${method} '${url}' failed with status ${status}: ${errorResponse}`);\n        } else {\n            super(`${method} '${url}' failed with status ${status}`);\n        }\n        this.status = status;\n        this.errorResponse = errorResponse;\n    }\n}\n\nclass HttpConnectError extends Error {\n    constructor(method, url, message) {\n        super(`${method} '${url}' connect failed: ${message}`);\n        this.method = method;\n        this.url = url;\n    }\n}\n\nclass HttpStreamError extends Error {\n    constructor(method, url, status, message) {\n        super(`${method} '${url}' stream ${status} response failed: ${message}`);\n        this.method = method;\n        this.url = url;\n        this.status = status;\n    }\n}\n\nmodule.exports = {\n    HttpResponseError,\n    HttpConnectError,\n    HttpStreamError\n}\n\n\n//# sourceURL=./lib/error.js");

/***/ }),

/***/ "./lib/fetch.js":
/*!**********************!*\
  !*** ./lib/fetch.js ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\n__webpack_require__(/*! isomorphic-fetch */ \"./node_modules/isomorphic-fetch/fetch-npm-node.js\");\nconst { HttpResponseError, HttpConnectError, HttpStreamError } = __webpack_require__(/*! ./error */ \"./lib/error.js\");\n\n// I could not find a way to return a stream from fetch() using nock that would fail when read.\n// The error is passed through, but it ends up being emitted on a client message object internally\n// which is not caught.\n// The code below is meant for unit testing only, and overrides the stream returned by fetch/nock.\n// It does this once and resets back to the default state.\n\nconst responseBodyOverride = {};\n\n/**\n * Override the stream returned by fetch for unit testing stream failures\n * \n * @param {String} method HTTP method for which to return the provided stream\n * @param {Readable} stream Readable stream\n */\nfunction testSetResponseBodyOverride(method, stream) {\n    responseBodyOverride[method] = stream;        \n}\n\n/**\n * Return true if any response body overrides are in place\n */\nfunction testHasResponseBodyOverrides() {\n    return Object.entries(responseBodyOverride).length > 0\n}\n\n/**\n * Override the response body\n * \n * @param {String} method Method\n * @param {Response} response Fetch response\n */\nfunction testOverrideResponseBody(method, response) {\n    if (responseBodyOverride[method]) {\n        response.body = responseBodyOverride[method];\n        delete responseBodyOverride[method];\n    }\n}\n\n/**\n * Check if response is user readable text\n * \n * @param {Headers} headers Node-fetch headers\n */\nfunction isTextContent(headers) {\n    const contentType = headers.get(\"content-type\");\n    return contentType && (\n        contentType.startsWith(\"text/\") || \n        contentType.startsWith(\"application/xml\") ||\n        contentType.startsWith(\"application/json\")\n    );\n}\n\n/**\n * Read a UTF8 text stream\n * \n * @param {stream.Readable} stream Readable stream\n * @param {Number} maxLength Maximum number of characters to read\n * @param {Function} callback Callback with the text that was read\n */\nasync function readTextStream(stream, maxLength) {\n    return new Promise((resolve, reject) => {\n        let text = \"\";\n        let totalLength = 0;\n        stream.setEncoding(\"utf8\");\n        stream.on(\"data\", chunk => {\n            totalLength += chunk.length;\n            const remaining = maxLength - Math.min(text.length, maxLength);\n            if (remaining > 0) {\n                text += chunk.substr(0, Math.min(chunk.length, remaining));\n            }\n        });\n        stream.on(\"end\", () => {\n            if (totalLength > maxLength) {\n                return resolve(`${text}...`);\n            } else {\n                return resolve(text);\n            }\n        });\n        stream.on(\"error\", error => {\n            reject(error);\n        });\n    });\n}\n\n/**\n * Issue an streaming HTTP request with error handling\n * \n * @param {String} method HTTP method \n * @param {String} url URL to connect to\n * @param {Object} options Fetch options\n */\nasync function stream(method, url, options) {\n    const request = Object.assign({ method }, options);\n    let response;\n    try {\n        // fetch is defined globally by isomorphic-fetch\n        // eslint-disable-next-line no-undef\n        response = await fetch(url, request);\n        testOverrideResponseBody(method, response);\n    } catch (e) {\n        throw new HttpConnectError(request.method, url, e.message);\n    }\n\n    if (!response.ok) {\n        let message;\n        if (isTextContent(response.headers)) {\n            try {\n                message = await readTextStream(response.body, 10000);\n            } catch (e) {\n                throw new HttpStreamError(request.method, url, response.status, e);\n            }\n        }\n        throw new HttpResponseError(request.method, url, response.status, message);\n    } else {\n        return response;\n    }\n}\n\n/**\n * Retrieve headers and status from the given URL. \n * Defaults to \"HEAD\" method.\n * The response stream is closed on success.\n * \n * @param {String} url URL to download \n * @param {Object} options Fetch options\n */\nasync function issueHead(url, options) {\n    const response = await stream(\"HEAD\", url, options);\n    response.body.destroy();\n    return response;\n}\n\n/**\n * Download content from the given URL. \n * Defaults to \"GET\" method.\n * \n * @param {String} url URL to download \n * @param {Object} options Fetch options\n */\nasync function streamGet(url, options) {\n    return stream(\"GET\", url, options);\n}\n\n/**\n * Upload content to the given URL. \n * Defaults to \"PUT\" method.\n * The response stream is closed on success.\n * \n * @param {String} url URL to download \n * @param {Object} options Fetch options\n */\nasync function issuePut(url, options) {\n    const response = await stream(\"PUT\", url, options);\n    response.body.destroy();\n    return response;\n}\n\nmodule.exports = {\n    issueHead,\n    streamGet,\n    issuePut,\n    testSetResponseBodyOverride,\n    testHasResponseBodyOverrides\n};\n\n\n//# sourceURL=./lib/fetch.js");

/***/ }),

/***/ "./lib/file.js":
/*!*********************!*\
  !*** ./lib/file.js ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\nconst filterObject = __webpack_require__(/*! filter-obj */ \"./node_modules/filter-obj/index.js\");\nconst fs = __webpack_require__(/*! fs */ \"fs\").promises;\nconst fse = __webpack_require__(/*! fs-extra */ \"./node_modules/fs-extra/lib/index.js\");\nconst path = __webpack_require__(/*! path */ \"path\");\nconst { downloadStream, uploadStream } = __webpack_require__(/*! ./stream */ \"./lib/stream.js\");\nconst { createReadStream, createWriteStream } = __webpack_require__(/*! ./util */ \"./lib/util.js\");\nconst { retry } = __webpack_require__(/*! ./retry */ \"./lib/retry.js\");\nconst { HttpStreamError } = __webpack_require__(/*! ./error */ \"./lib/error.js\");\n\n/**\n * @typedef {Object} DownloadFileOptions\n * \n * @property {Number} [timeout] Socket timeout\n * @property {Object} [headers] An object containing request headers\n * @property {Boolean} [mkdirs] True if the directory of the filepath should be created\n * @property {Number} [retryMax=60000] time to retry until throwing an error (ms)\n * @property {Number} [retryInterval=100] time between retries, used by exponential backoff (ms)\n * @property {Boolean} [retryEnabled=true] retry on failure enabled\n * @property {Boolean} [retryAllErrors=false] whether or not to retry on all http error codes or just >=500\n */\n/**\n * Download a file from an url\n * \n * @param {String|URL} url Source URL\n * @param {String} filepath Target file path\n * @param {DownloadFileOptions} [options] Download options\n * @returns {Promise} resolves when download completes\n */\nasync function downloadFile(url, filepath, options) {\n    return retry(async options => {\n        if (options && options.mkdirs) {\n            await fse.ensureDir(path.dirname(filepath));\n        }\n        const writeStream = await createWriteStream(filepath);\n        const transferred = await downloadStream(url, writeStream, options);\n        const { size } = await fs.stat(filepath);\n        if (size !== transferred) {\n            throw new HttpStreamError(\"GET\", url, 200, `Response truncated at ${size} bytes, received ${transferred} bytes`);\n        }\n    }, options);\n}\n\n/**\n * @typedef {Object} UploadFileOptions\n * \n * @property {String} [method] HTTP method (defaults to 'PUT')\n * @property {Number} [timeout] Socket timeout\n * @property {Object} [headers] An object containing request headers\n * @property {Number} [start] Offset of the first byte in the file to upload (inclusive)\n * @property {Number} [end] Offset of the last byte in the file to upload (inclusive)\n * @property {Number} [retryMax=60000] time to retry until throwing an error (ms)\n * @property {Number} [retryInterval=100] time between retries, used by exponential backoff (ms)\n * @property {Boolean} [retryEnabled=true] retry on failure enabled\n * @property {Boolean} [retryAllErrors=false] whether or not to retry on all http error codes or just >=500\n * \n * Note that the start and end offsets are not passed to the server. This is intentional.\n * Range upload requests are not widely supported, although could be added optionally.\n */\n/**\n * Upload a file to an url\n * \n * @param {String} filepath Source file path\n * @param {String} url Target URL\n * @param {UploadFileOptions} [options] Upload options\n * @returns {Promise} resolves when upload completes\n */\nasync function uploadFile(filepath, url, options) {\n    return retry(async options => {\n        // determine the content length\n        let contentLength;\n        let readStream;\n        if (options && options.end) {\n            const start = options.start || 0;\n            contentLength = options.end - start + 1;\n            readStream = await createReadStream(filepath, {\n                start,\n                end: options.end\n            });\n        } else {\n            const { size } = await fs.stat(filepath);\n            contentLength = size;\n            readStream = await createReadStream(filepath);\n        }\n\n        // extract upload options\n        const uploadOptions = filterObject(\n            options || {},\n            ['method', 'timeout', 'headers']\n        );\n        uploadOptions.headers = Object.assign({}, uploadOptions.headers, {\n            'content-length': contentLength\n        });\n\n        // upload file\n        return uploadStream(readStream, url, uploadOptions);\n    }, options);\n}\n\nmodule.exports = {\n    downloadFile,\n    uploadFile\n}\n\n\n//# sourceURL=./lib/file.js");

/***/ }),

/***/ "./lib/headers.js":
/*!************************!*\
  !*** ./lib/headers.js ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\nconst fetch = __webpack_require__(/*! ./fetch */ \"./lib/fetch.js\");\nconst { retry } = __webpack_require__(/*! ./retry */ \"./lib/retry.js\");\nconst contentRangeParser = __webpack_require__(/*! content-range */ \"./node_modules/content-range/index.js\");\nconst contentTypeParser = __webpack_require__(/*! content-type */ \"content-type\");\nconst contentDispositionParser = __webpack_require__(/*! content-disposition */ \"content-disposition\");\n\nasync function getHeaders(url, options) {\n    const fetchOptions = Object.assign({\n        timeout: options && options.timeout,\n        headers: Object.assign({}, options && options.headers)\n    })\n    if (options && options.doGet) {\n        fetchOptions.method = \"GET\";\n        fetchOptions.headers.range = \"bytes=0-0\";\n    }\n    const response = await fetch.issueHead(url, fetchOptions);\n    return response.headers;\n}\n\nfunction getFilename(headers) {\n    const contentDisposition = headers.get(\"content-disposition\");\n    if (contentDisposition) {\n        try {\n            const parsed = contentDispositionParser.parse(contentDisposition, {\n                fallback: false\n            });\n            return parsed && parsed.parameters && parsed.parameters.filename;\n        } catch (e) {\n            console.warn(`Unable to parse 'content-disposition' header: ${contentDisposition}`, e.message || e);\n        }\n    } else {\n        return null;\n    }\n}\n\nfunction getMimetype(headers) {\n    const contentType = headers.get(\"content-type\");\n    if (contentType) {\n        try {\n            const parsed = contentTypeParser.parse(contentType);\n            return parsed && parsed.type;\n        } catch (e) {\n            console.warn(`Unable to parse 'content-type' header: ${contentType}`, e.message || e);\n        }\n    } else {\n        return null;\n    }\n}\n\nfunction getSize(headers) {\n    const contentRange = headers.get(\"content-range\");\n    const contentLength = headers.get(\"content-length\");\n    const parsed = contentRangeParser.parse(contentRange);\n    return (parsed && parsed.length) || (contentLength && parseInt(contentLength))\n}\n\n/**\n * @typedef {Object} ResourceHeaders\n * \n * @property {String} filename Resource filename (if available)\n * @property {String} mimetype Resource mimetype (if available)\n * @property {Number} size Resource size in bytes (if available)\n */\n/**\n * Parse headers\n * \n * @param {Headers} headers Headers returned by node-fetch\n * @returns {ResourceHeaders} parsed resource headers\n */\nfunction parseResourceHeaders(headers) {\n    const result = {\n        mimetype: getMimetype(headers) || \"application/octet-stream\",\n        size: getSize(headers) || 0\n    };\n    const filename = getFilename(headers);\n    if (filename) {\n        result.filename = filename;\n    }\n    return result;\n}\n\n/**\n * @typedef {Object} GetResourceHeadersOptions\n * @property {Object} headers An object containing request headers\n * @property {Number} timeout Socket timeout\n * @property {Boolean} doGet Use the HTTP GET method to fetch response headers\n * @property {Number} [retryMax=60000] time to retry until throwing an error (ms)\n * @property {Number} [retryInterval=100] time between retries, used by exponential backoff (ms)\n * @property {Boolean} [retryEnabled=true] retry on failure enabled\n * @property {Boolean} [retryAllErrors=false] whether or not to retry on all http error codes or just >=500\n */\n/**\n * Retrieve content information \n * \n * @param {String} url URL to request content headers for\n * @param {GetResourceHeadersOptions} options Resource header options\n * @returns {ResourceHeaders} content headers\n */\nasync function getResourceHeaders(url, options) {\n    return retry(async options => {\n        const headers = await getHeaders(url, options);\n        return parseResourceHeaders(headers);    \n    }, options);\n}\n\nmodule.exports = {\n    parseResourceHeaders,\n    getResourceHeaders\n}\n\n\n//# sourceURL=./lib/headers.js");

/***/ }),

/***/ "./lib/retry.js":
/*!**********************!*\
  !*** ./lib/retry.js ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\nconst filterObject = __webpack_require__(/*! filter-obj */ \"./node_modules/filter-obj/index.js\");\nconst { HttpConnectError, HttpStreamError, HttpResponseError } = __webpack_require__(/*! ./error */ \"./lib/error.js\");\n\nconst DEFAULT_INTERVAL_MILLIS = 100;\nconst DEFAULT_MAX_MILLIS = 60000;\n\n/**\n * @typedef {Object} RetryOptions\n * @property {Date} startTime start time using `Date.now()`\n * @property {Number} retryMax time to retry until throwing an error\n * @property {Number} retryInterval time between retries, used by exponential backoff (ms)\n * @property {Boolean} retryAllErrors whether or not to retry on all http error codes or just >=500\n */\n\n /**\n * Initialize retry options\n * \n * @param {Object} ]options=] Optional object containing retry options\n * @returns {RetryOptions} Resolved retry options\n */\nfunction retryOptions(options) {\n    // only disable when retryEnabled is set to false explicitly\n    if (!options || (options.retryEnabled !== false)) {\n        return {\n            startTime: Date.now(),\n            retryMax: (options && options.retryMax) || DEFAULT_MAX_MILLIS,\n            retryInterval: (options && options.retryInterval) || DEFAULT_INTERVAL_MILLIS,\n            retryAllErrors: (options && options.retryAllErrors) || false\n        }\n    } else {\n        return null;\n    }\n}\n\n/**\n * Filter out the retry options\n * \n * @param {Object} options Options  \n * @returns {Object} Filtered options\n */\nfunction filterOptions(options) {\n    return options && filterObject(options, key => [\n        \"retryEnabled\",\n        \"retryMax\",\n        \"retryInterval\",\n        \"retryAllErrors\"\n    ].indexOf(key) < 0);\n}\n\n/**\n * Calculate the retry delay\n * \n * @param {Number} attempt Attempt count\n * @param {RetryOptions} options Retry options\n * @param {Boolean} [random=true] Add randomness\n */\nfunction retryDelay(attempt, interval, random=true) {\n    // 2^attempt * interval + 0-100ms random\n    return (2**attempt) * interval + \n        (random ? Math.floor(Math.random() * 100) : 99);\n}\n\n/**\n * Check whether a given error requires retry\n * \n * @param {Number} attempt Attempt count\n * @param {Error} error Error to analyze\n * @param {RetryOptions} options Retry options\n */\nfunction retryOn(attempt, error, options) {\n    if (options) {\n        const waited = Date.now() - options.startTime;\n        const toWait = retryDelay(attempt, options.retryInterval, false) + waited;\n        return (toWait < options.retryMax) && (\n            (error instanceof HttpConnectError) ||\n            (error instanceof HttpStreamError)  ||\n            ((error instanceof HttpResponseError) && \n                (options.retryAllErrors || error.status >= 500)\n            )\n        );\n    } else {\n        return false;\n    }\n}\n\n/**\n * Invoke a function with retry one failure support\n * \n * @param {Function} asyncFunc Asynchronous function to call\n * @param {Object} options Options to pass to asynchronous function\n * @param {RetryOptions} retryOptions Retry options\n */\nasync function retryInvoke(asyncFunc, options, retryOptions) {\n    return new Promise((resolve, reject) => {\n        async function invoke(attempt, ms) {\n            try {\n                if (attempt > 0) {\n                    console.error(`Attempting retry ${attempt} after waiting ${ms} milliseconds.`);\n                }\n                return resolve(await asyncFunc(options));\n            } catch (e) {\n                if (retryOn(attempt, e, retryOptions)) {\n                    const ms = retryDelay(attempt, retryOptions.retryInterval);\n                    console.error(`Waiting ${ms} milliseconds to attempt retry ${attempt + 1}, failure: ${e.message}`);\n                    setTimeout(invoke, ms, attempt + 1, ms);\n                } else {\n                    return reject(e);\n                }\n            }\n        }\n        setImmediate(invoke, 0, 0);\n    });\n}\n\n/**\n * Add retry support to the given asynchronous function\n * \n * @param {Function} asyncFunc Asynchronous function\n * @returns Asynchronous function with retry support\n */\nasync function retry(asyncFunc, options) {\n    const retry = retryOptions(options);\n    options = filterOptions(options);\n    return retryInvoke(asyncFunc, options, retry);\n}\n\nmodule.exports = {\n    retry\n}\n\n\n//# sourceURL=./lib/retry.js");

/***/ }),

/***/ "./lib/stream.js":
/*!***********************!*\
  !*** ./lib/stream.js ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\nconst fetch = __webpack_require__(/*! ./fetch */ \"./lib/fetch.js\");\nconst { retry } = __webpack_require__(/*! ./retry */ \"./lib/retry.js\");\nconst { parseResourceHeaders } = __webpack_require__(/*! ./headers */ \"./lib/headers.js\");\nconst { HttpStreamError } = __webpack_require__(/*! ./error */ \"./lib/error.js\");\n\n/**\n * @typedef {Object} DownloadStreamOptions\n * \n * @property {Number} timeout Socket timeout\n * @property {Object} headers An object containing request headers\n */\n/**\n * Download content from a URL and write it to a stream\n * \n * @param {String|URL} url Source URL\n * @param {Object} writeStream Target writable stream\n * \n * @param {DownloadStreamOptions} options Download options\n * @returns {Promise} resolves to the number of bytes downloaded\n */\nasync function downloadStream(url, writeStream, options) {\n    const response = await fetch.streamGet(url, options);\n    const expectedBytes = parseResourceHeaders(response.headers).size;\n    let actualBytes = 0;\n    return new Promise((resolve, reject) => {\n        response.body\n            .on('data', chunk => {\n                actualBytes += chunk.length;\n            })\n            .on(\"error\", err => {\n                reject(new HttpStreamError(\"GET\", url, response.status, err.message))\n            })            \n            .pipe(writeStream)\n            .on(\"error\", err => {\n                reject(new HttpStreamError(\"GET\", url, response.status, err.message))\n            })\n            .on(\"finish\", () => {\n                if (expectedBytes && (actualBytes !== expectedBytes)) {\n                    reject(new HttpStreamError(\"GET\", url, response.status, `Response truncated at ${actualBytes} bytes, received ${expectedBytes} bytes`));\n                }\n                resolve(actualBytes);\n            });\n    });\n}\n\n/**\n * @typedef {Object} UploadStreamOptions\n * \n * @property {String} method HTTP method (defaults to 'PUT')\n * @property {Number} timeout Socket timeout\n * @property {Object} headers An object containing request headers\n */\n/**\n * Upload a stream of data to a URL\n * \n * @param {Object} readStream Source readable stream\n * @param {String} url Target URL\n * @param {UploadStreamOptions} options Upload options\n * @returns {Promise} resolves when upload completes\n */\nasync function uploadStream(readStream, url, options) {\n    return fetch.issuePut(\n        url, \n        Object.assign({\n            body: readStream\n        }, options)\n    );\n}\n\n/**\n * @typedef {Object} TransferStreamOptions\n * \n * @property {DownloadStreamOptions} source Source options\n * @property {UploadStreamOptions} target Target options\n * @property {Number} [retryMax=60000] time to retry until throwing an error (ms)\n * @property {Number} [retryInterval=100] time between retries, used by exponential backoff (ms)\n * @property {Boolean} [retryEnabled=true] retry on failure enabled\n * @property {Boolean} [retryAllErrors=false] whether or not to retry on all http error codes or just >=500\n */\n/**\n * Transfer a stream of content from one url to another\n * \n * @param {String} sourceUrl Source URL\n * @param {String} targetUrl Target URL\n * @param {TransferStreamOptions} options Transfer options\n * @returns {Promise} resolves when transfer completes\n */\nasync function transferStream(sourceUrl, targetUrl, options) {\n    return retry(async options => {\n        const response = await fetch.streamGet(sourceUrl, options && options.source);\n\n        // resolve headers, allow override by options\n        const resourceHeaders = parseResourceHeaders(response.headers);\n        const contentType = response.headers.get(\"content-type\") || \"application/octet-stream\";\n        const headers = Object.assign({\n            \"content-length\": resourceHeaders.size,\n            \"content-type\": contentType\n        }, options && options.target && options.target.headers);\n\n        // resolve options, headers last since they are already resolved\n        const targetOptions = Object.assign({}, \n            options && options.target, { \n            headers \n        });\n        return uploadStream(response.body, targetUrl, targetOptions);\n    }, options);\n}\n\nmodule.exports = {\n    downloadStream,\n    uploadStream,\n    transferStream\n}\n\n\n//# sourceURL=./lib/stream.js");

/***/ }),

/***/ "./lib/util.js":
/*!*********************!*\
  !*** ./lib/util.js ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("/*\nCopyright 2019 Adobe. All rights reserved.\nThis file is licensed to you under the Apache License, Version 2.0 (the \"License\");\nyou may not use this file except in compliance with the License. You may obtain a copy\nof the License at http://www.apache.org/licenses/LICENSE-2.0\n\nUnless required by applicable law or agreed to in writing, software distributed under\nthe License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS\nOF ANY KIND, either express or implied. See the License for the specific language\ngoverning permissions and limitations under the License.\n*/\n\n\n\nconst fs = __webpack_require__(/*! fs */ \"fs\");\n\n/**\n * Async function to open a read stream. Resolves on open event.\n * \n * @param {String} path Path to file to open\n * @param {Object} options Options\n */\nfunction createReadStream(path, options) {\n    return new Promise((resolve, reject) => {\n        const readStream = fs.createReadStream(path, options);\n        readStream.on('open', () => {\n            resolve(readStream);\n        })\n        const errorCallback = (error) => {\n            readStream.removeListener('error', errorCallback);\n            reject(error);\n        }\n        readStream.on('error', errorCallback);\n    });\n}\n\n/**\n * Async function to open a write stream. Resolves on open event.\n * \n * @param {String} path Path to file to open\n * @param {Object} options Options\n */\nfunction createWriteStream(path, options) {\n    return new Promise((resolve, reject) => {\n        const writeStream = fs.createWriteStream(path, options);\n        writeStream.on('open', () => {\n            // only issued once\n            resolve(writeStream);\n        })\n        const errorCallback = (error) => {\n            // remove itself to prevent any future callbacks\n            writeStream.removeListener('error', errorCallback);\n            reject(error);\n        }\n        writeStream.on('error', errorCallback);\n    });\n}\n\nmodule.exports = {\n    createReadStream,\n    createWriteStream\n}\n\n\n//# sourceURL=./lib/util.js");

/***/ }),

/***/ "./node_modules/content-range/index.js":
/*!*********************************************!*\
  !*** ./node_modules/content-range/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (root, factory) {\n  // AMD\n  if (true) !(__WEBPACK_AMD_DEFINE_ARRAY__ = [exports], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),\n\t\t\t\t__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?\n\t\t\t\t(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),\n\t\t\t\t__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));\n  // Common JS\n  else {}\n}(this, function (exports) {\n\n  /**\n   * Expose module.\n   */\n\n  exports.format = format;\n  exports.parse = parse;\n\n  /**\n   * Format the content-range header.\n   *\n   * @param {Object} options\n   * @param {String} options.unit\n   * @param {Number} options.start\n   * @param {Number} options.limit\n   * @param {Number} options.length\n   */\n\n  function format(options) {\n    options.length = options.length == null ? '*' : options.length;\n\n    var first = options.first;\n    var last = options.last || (options.first + options.limit - 1);\n\n    if (last - first < 0) return options.unit + ' */' + options.length;\n\n    return options.unit + ' ' + first + '-' + last + '/' + options.length;\n  }\n\n  /**\n   * Parse the content-range header.\n   *\n   * @param {String} str\n   * @returns {Object}\n   */\n\n  function parse(str) {\n    var matches;\n\n    if (typeof str !== \"string\") return null;\n\n    if (matches = str.match(/^(\\w+) (\\d+)-(\\d+)\\/(\\d+|\\*)/)) return {\n        unit: matches[1],\n        first: +matches[2],\n        last: +matches[3],\n        length: matches[4] === '*' ? null : +matches[4]\n      };\n\n    if (matches = str.match(/^(\\w+) \\*\\/(\\d+|\\*)/)) return {\n        unit: matches[1],\n        first: null,\n        last: null,\n        length: matches[2] === '*' ? null : +matches[2]\n      };\n\n    return null;\n  }\n\n}));\n\n\n//# sourceURL=./node_modules/content-range/index.js");

/***/ }),

/***/ "./node_modules/encoding/lib sync recursive":
/*!****************************************!*\
  !*** ./node_modules/encoding/lib sync ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("function webpackEmptyContext(req) {\n\tvar e = new Error(\"Cannot find module '\" + req + \"'\");\n\te.code = 'MODULE_NOT_FOUND';\n\tthrow e;\n}\nwebpackEmptyContext.keys = function() { return []; };\nwebpackEmptyContext.resolve = webpackEmptyContext;\nmodule.exports = webpackEmptyContext;\nwebpackEmptyContext.id = \"./node_modules/encoding/lib sync recursive\";\n\n//# sourceURL=./node_modules/encoding/lib_sync");

/***/ }),

/***/ "./node_modules/encoding/lib/encoding.js":
/*!***********************************************!*\
  !*** ./node_modules/encoding/lib/encoding.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar iconvLite = __webpack_require__(/*! iconv-lite */ \"iconv-lite\");\n// Load Iconv from an external file to be able to disable Iconv for webpack\n// Add /\\/iconv-loader$/ to webpack.IgnorePlugin to ignore it\nvar Iconv = __webpack_require__(/*! ./iconv-loader */ \"./node_modules/encoding/lib/iconv-loader.js\");\n\n// Expose to the world\nmodule.exports.convert = convert;\n\n/**\n * Convert encoding of an UTF-8 string or a buffer\n *\n * @param {String|Buffer} str String to be converted\n * @param {String} to Encoding to be converted to\n * @param {String} [from='UTF-8'] Encoding to be converted from\n * @param {Boolean} useLite If set to ture, force to use iconvLite\n * @return {Buffer} Encoded string\n */\nfunction convert(str, to, from, useLite) {\n    from = checkEncoding(from || 'UTF-8');\n    to = checkEncoding(to || 'UTF-8');\n    str = str || '';\n\n    var result;\n\n    if (from !== 'UTF-8' && typeof str === 'string') {\n        str = new Buffer(str, 'binary');\n    }\n\n    if (from === to) {\n        if (typeof str === 'string') {\n            result = new Buffer(str);\n        } else {\n            result = str;\n        }\n    } else if (Iconv && !useLite) {\n        try {\n            result = convertIconv(str, to, from);\n        } catch (E) {\n            console.error(E);\n            try {\n                result = convertIconvLite(str, to, from);\n            } catch (E) {\n                console.error(E);\n                result = str;\n            }\n        }\n    } else {\n        try {\n            result = convertIconvLite(str, to, from);\n        } catch (E) {\n            console.error(E);\n            result = str;\n        }\n    }\n\n\n    if (typeof result === 'string') {\n        result = new Buffer(result, 'utf-8');\n    }\n\n    return result;\n}\n\n/**\n * Convert encoding of a string with node-iconv (if available)\n *\n * @param {String|Buffer} str String to be converted\n * @param {String} to Encoding to be converted to\n * @param {String} [from='UTF-8'] Encoding to be converted from\n * @return {Buffer} Encoded string\n */\nfunction convertIconv(str, to, from) {\n    var response, iconv;\n    iconv = new Iconv(from, to + '//TRANSLIT//IGNORE');\n    response = iconv.convert(str);\n    return response.slice(0, response.length);\n}\n\n/**\n * Convert encoding of astring with iconv-lite\n *\n * @param {String|Buffer} str String to be converted\n * @param {String} to Encoding to be converted to\n * @param {String} [from='UTF-8'] Encoding to be converted from\n * @return {Buffer} Encoded string\n */\nfunction convertIconvLite(str, to, from) {\n    if (to === 'UTF-8') {\n        return iconvLite.decode(str, from);\n    } else if (from === 'UTF-8') {\n        return iconvLite.encode(str, to);\n    } else {\n        return iconvLite.encode(iconvLite.decode(str, from), to);\n    }\n}\n\n/**\n * Converts charset name if needed\n *\n * @param {String} name Character set\n * @return {String} Character set name\n */\nfunction checkEncoding(name) {\n    return (name || '').toString().trim().\n    replace(/^latin[\\-_]?(\\d+)$/i, 'ISO-8859-$1').\n    replace(/^win(?:dows)?[\\-_]?(\\d+)$/i, 'WINDOWS-$1').\n    replace(/^utf[\\-_]?(\\d+)$/i, 'UTF-$1').\n    replace(/^ks_c_5601\\-1987$/i, 'CP949').\n    replace(/^us[\\-_]?ascii$/i, 'ASCII').\n    toUpperCase();\n}\n\n\n//# sourceURL=./node_modules/encoding/lib/encoding.js");

/***/ }),

/***/ "./node_modules/encoding/lib/iconv-loader.js":
/*!***************************************************!*\
  !*** ./node_modules/encoding/lib/iconv-loader.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar iconv_package;\nvar Iconv;\n\ntry {\n    // this is to fool browserify so it doesn't try (in vain) to install iconv.\n    iconv_package = 'iconv';\n    Iconv = __webpack_require__(\"./node_modules/encoding/lib sync recursive\")(iconv_package).Iconv;\n} catch (E) {\n    // node-iconv not present\n}\n\nmodule.exports = Iconv;\n\n\n//# sourceURL=./node_modules/encoding/lib/iconv-loader.js");

/***/ }),

/***/ "./node_modules/filter-obj/index.js":
/*!******************************************!*\
  !*** ./node_modules/filter-obj/index.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nmodule.exports = (object, predicate) => {\n\tconst result = {};\n\tconst isArray = Array.isArray(predicate);\n\n\tfor (const [key, value] of Object.entries(object)) {\n\t\tif (isArray ? predicate.includes(key) : predicate(key, value, object)) {\n\t\t\tresult[key] = value;\n\t\t}\n\t}\n\n\treturn result;\n};\n\n\n//# sourceURL=./node_modules/filter-obj/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/copy-sync/copy-sync.js":
/*!**********************************************************!*\
  !*** ./node_modules/fs-extra/lib/copy-sync/copy-sync.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst mkdirpSync = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\").mkdirsSync\nconst utimesSync = __webpack_require__(/*! ../util/utimes.js */ \"./node_modules/fs-extra/lib/util/utimes.js\").utimesMillisSync\nconst stat = __webpack_require__(/*! ../util/stat */ \"./node_modules/fs-extra/lib/util/stat.js\")\n\nfunction copySync (src, dest, opts) {\n  if (typeof opts === 'function') {\n    opts = { filter: opts }\n  }\n\n  opts = opts || {}\n  opts.clobber = 'clobber' in opts ? !!opts.clobber : true // default to true for now\n  opts.overwrite = 'overwrite' in opts ? !!opts.overwrite : opts.clobber // overwrite falls back to clobber\n\n  // Warn about using preserveTimestamps on 32-bit node\n  if (opts.preserveTimestamps && process.arch === 'ia32') {\n    console.warn(`fs-extra: Using the preserveTimestamps option in 32-bit node is not recommended;\\n\n    see https://github.com/jprichardson/node-fs-extra/issues/269`)\n  }\n\n  const { srcStat, destStat } = stat.checkPathsSync(src, dest, 'copy')\n  stat.checkParentPathsSync(src, srcStat, dest, 'copy')\n  return handleFilterAndCopy(destStat, src, dest, opts)\n}\n\nfunction handleFilterAndCopy (destStat, src, dest, opts) {\n  if (opts.filter && !opts.filter(src, dest)) return\n  const destParent = path.dirname(dest)\n  if (!fs.existsSync(destParent)) mkdirpSync(destParent)\n  return startCopy(destStat, src, dest, opts)\n}\n\nfunction startCopy (destStat, src, dest, opts) {\n  if (opts.filter && !opts.filter(src, dest)) return\n  return getStats(destStat, src, dest, opts)\n}\n\nfunction getStats (destStat, src, dest, opts) {\n  const statSync = opts.dereference ? fs.statSync : fs.lstatSync\n  const srcStat = statSync(src)\n\n  if (srcStat.isDirectory()) return onDir(srcStat, destStat, src, dest, opts)\n  else if (srcStat.isFile() ||\n           srcStat.isCharacterDevice() ||\n           srcStat.isBlockDevice()) return onFile(srcStat, destStat, src, dest, opts)\n  else if (srcStat.isSymbolicLink()) return onLink(destStat, src, dest, opts)\n}\n\nfunction onFile (srcStat, destStat, src, dest, opts) {\n  if (!destStat) return copyFile(srcStat, src, dest, opts)\n  return mayCopyFile(srcStat, src, dest, opts)\n}\n\nfunction mayCopyFile (srcStat, src, dest, opts) {\n  if (opts.overwrite) {\n    fs.unlinkSync(dest)\n    return copyFile(srcStat, src, dest, opts)\n  } else if (opts.errorOnExist) {\n    throw new Error(`'${dest}' already exists`)\n  }\n}\n\nfunction copyFile (srcStat, src, dest, opts) {\n  if (typeof fs.copyFileSync === 'function') {\n    fs.copyFileSync(src, dest)\n    fs.chmodSync(dest, srcStat.mode)\n    if (opts.preserveTimestamps) {\n      return utimesSync(dest, srcStat.atime, srcStat.mtime)\n    }\n    return\n  }\n  return copyFileFallback(srcStat, src, dest, opts)\n}\n\nfunction copyFileFallback (srcStat, src, dest, opts) {\n  const BUF_LENGTH = 64 * 1024\n  const _buff = __webpack_require__(/*! ../util/buffer */ \"./node_modules/fs-extra/lib/util/buffer.js\")(BUF_LENGTH)\n\n  const fdr = fs.openSync(src, 'r')\n  const fdw = fs.openSync(dest, 'w', srcStat.mode)\n  let pos = 0\n\n  while (pos < srcStat.size) {\n    const bytesRead = fs.readSync(fdr, _buff, 0, BUF_LENGTH, pos)\n    fs.writeSync(fdw, _buff, 0, bytesRead)\n    pos += bytesRead\n  }\n\n  if (opts.preserveTimestamps) fs.futimesSync(fdw, srcStat.atime, srcStat.mtime)\n\n  fs.closeSync(fdr)\n  fs.closeSync(fdw)\n}\n\nfunction onDir (srcStat, destStat, src, dest, opts) {\n  if (!destStat) return mkDirAndCopy(srcStat, src, dest, opts)\n  if (destStat && !destStat.isDirectory()) {\n    throw new Error(`Cannot overwrite non-directory '${dest}' with directory '${src}'.`)\n  }\n  return copyDir(src, dest, opts)\n}\n\nfunction mkDirAndCopy (srcStat, src, dest, opts) {\n  fs.mkdirSync(dest)\n  copyDir(src, dest, opts)\n  return fs.chmodSync(dest, srcStat.mode)\n}\n\nfunction copyDir (src, dest, opts) {\n  fs.readdirSync(src).forEach(item => copyDirItem(item, src, dest, opts))\n}\n\nfunction copyDirItem (item, src, dest, opts) {\n  const srcItem = path.join(src, item)\n  const destItem = path.join(dest, item)\n  const { destStat } = stat.checkPathsSync(srcItem, destItem, 'copy')\n  return startCopy(destStat, srcItem, destItem, opts)\n}\n\nfunction onLink (destStat, src, dest, opts) {\n  let resolvedSrc = fs.readlinkSync(src)\n  if (opts.dereference) {\n    resolvedSrc = path.resolve(process.cwd(), resolvedSrc)\n  }\n\n  if (!destStat) {\n    return fs.symlinkSync(resolvedSrc, dest)\n  } else {\n    let resolvedDest\n    try {\n      resolvedDest = fs.readlinkSync(dest)\n    } catch (err) {\n      // dest exists and is a regular file or directory,\n      // Windows may throw UNKNOWN error. If dest already exists,\n      // fs throws error anyway, so no need to guard against it here.\n      if (err.code === 'EINVAL' || err.code === 'UNKNOWN') return fs.symlinkSync(resolvedSrc, dest)\n      throw err\n    }\n    if (opts.dereference) {\n      resolvedDest = path.resolve(process.cwd(), resolvedDest)\n    }\n    if (stat.isSrcSubdir(resolvedSrc, resolvedDest)) {\n      throw new Error(`Cannot copy '${resolvedSrc}' to a subdirectory of itself, '${resolvedDest}'.`)\n    }\n\n    // prevent copy if src is a subdir of dest since unlinking\n    // dest in this case would result in removing src contents\n    // and therefore a broken symlink would be created.\n    if (fs.statSync(dest).isDirectory() && stat.isSrcSubdir(resolvedDest, resolvedSrc)) {\n      throw new Error(`Cannot overwrite '${resolvedDest}' with '${resolvedSrc}'.`)\n    }\n    return copyLink(resolvedSrc, dest)\n  }\n}\n\nfunction copyLink (resolvedSrc, dest) {\n  fs.unlinkSync(dest)\n  return fs.symlinkSync(resolvedSrc, dest)\n}\n\nmodule.exports = copySync\n\n\n//# sourceURL=./node_modules/fs-extra/lib/copy-sync/copy-sync.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/copy-sync/index.js":
/*!******************************************************!*\
  !*** ./node_modules/fs-extra/lib/copy-sync/index.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nmodule.exports = {\n  copySync: __webpack_require__(/*! ./copy-sync */ \"./node_modules/fs-extra/lib/copy-sync/copy-sync.js\")\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/copy-sync/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/copy/copy.js":
/*!************************************************!*\
  !*** ./node_modules/fs-extra/lib/copy/copy.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst mkdirp = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\").mkdirs\nconst pathExists = __webpack_require__(/*! ../path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\").pathExists\nconst utimes = __webpack_require__(/*! ../util/utimes */ \"./node_modules/fs-extra/lib/util/utimes.js\").utimesMillis\nconst stat = __webpack_require__(/*! ../util/stat */ \"./node_modules/fs-extra/lib/util/stat.js\")\n\nfunction copy (src, dest, opts, cb) {\n  if (typeof opts === 'function' && !cb) {\n    cb = opts\n    opts = {}\n  } else if (typeof opts === 'function') {\n    opts = { filter: opts }\n  }\n\n  cb = cb || function () {}\n  opts = opts || {}\n\n  opts.clobber = 'clobber' in opts ? !!opts.clobber : true // default to true for now\n  opts.overwrite = 'overwrite' in opts ? !!opts.overwrite : opts.clobber // overwrite falls back to clobber\n\n  // Warn about using preserveTimestamps on 32-bit node\n  if (opts.preserveTimestamps && process.arch === 'ia32') {\n    console.warn(`fs-extra: Using the preserveTimestamps option in 32-bit node is not recommended;\\n\n    see https://github.com/jprichardson/node-fs-extra/issues/269`)\n  }\n\n  stat.checkPaths(src, dest, 'copy', (err, stats) => {\n    if (err) return cb(err)\n    const { srcStat, destStat } = stats\n    stat.checkParentPaths(src, srcStat, dest, 'copy', err => {\n      if (err) return cb(err)\n      if (opts.filter) return handleFilter(checkParentDir, destStat, src, dest, opts, cb)\n      return checkParentDir(destStat, src, dest, opts, cb)\n    })\n  })\n}\n\nfunction checkParentDir (destStat, src, dest, opts, cb) {\n  const destParent = path.dirname(dest)\n  pathExists(destParent, (err, dirExists) => {\n    if (err) return cb(err)\n    if (dirExists) return startCopy(destStat, src, dest, opts, cb)\n    mkdirp(destParent, err => {\n      if (err) return cb(err)\n      return startCopy(destStat, src, dest, opts, cb)\n    })\n  })\n}\n\nfunction handleFilter (onInclude, destStat, src, dest, opts, cb) {\n  Promise.resolve(opts.filter(src, dest)).then(include => {\n    if (include) return onInclude(destStat, src, dest, opts, cb)\n    return cb()\n  }, error => cb(error))\n}\n\nfunction startCopy (destStat, src, dest, opts, cb) {\n  if (opts.filter) return handleFilter(getStats, destStat, src, dest, opts, cb)\n  return getStats(destStat, src, dest, opts, cb)\n}\n\nfunction getStats (destStat, src, dest, opts, cb) {\n  const stat = opts.dereference ? fs.stat : fs.lstat\n  stat(src, (err, srcStat) => {\n    if (err) return cb(err)\n\n    if (srcStat.isDirectory()) return onDir(srcStat, destStat, src, dest, opts, cb)\n    else if (srcStat.isFile() ||\n             srcStat.isCharacterDevice() ||\n             srcStat.isBlockDevice()) return onFile(srcStat, destStat, src, dest, opts, cb)\n    else if (srcStat.isSymbolicLink()) return onLink(destStat, src, dest, opts, cb)\n  })\n}\n\nfunction onFile (srcStat, destStat, src, dest, opts, cb) {\n  if (!destStat) return copyFile(srcStat, src, dest, opts, cb)\n  return mayCopyFile(srcStat, src, dest, opts, cb)\n}\n\nfunction mayCopyFile (srcStat, src, dest, opts, cb) {\n  if (opts.overwrite) {\n    fs.unlink(dest, err => {\n      if (err) return cb(err)\n      return copyFile(srcStat, src, dest, opts, cb)\n    })\n  } else if (opts.errorOnExist) {\n    return cb(new Error(`'${dest}' already exists`))\n  } else return cb()\n}\n\nfunction copyFile (srcStat, src, dest, opts, cb) {\n  if (typeof fs.copyFile === 'function') {\n    return fs.copyFile(src, dest, err => {\n      if (err) return cb(err)\n      return setDestModeAndTimestamps(srcStat, dest, opts, cb)\n    })\n  }\n  return copyFileFallback(srcStat, src, dest, opts, cb)\n}\n\nfunction copyFileFallback (srcStat, src, dest, opts, cb) {\n  const rs = fs.createReadStream(src)\n  rs.on('error', err => cb(err)).once('open', () => {\n    const ws = fs.createWriteStream(dest, { mode: srcStat.mode })\n    ws.on('error', err => cb(err))\n      .on('open', () => rs.pipe(ws))\n      .once('close', () => setDestModeAndTimestamps(srcStat, dest, opts, cb))\n  })\n}\n\nfunction setDestModeAndTimestamps (srcStat, dest, opts, cb) {\n  fs.chmod(dest, srcStat.mode, err => {\n    if (err) return cb(err)\n    if (opts.preserveTimestamps) {\n      return utimes(dest, srcStat.atime, srcStat.mtime, cb)\n    }\n    return cb()\n  })\n}\n\nfunction onDir (srcStat, destStat, src, dest, opts, cb) {\n  if (!destStat) return mkDirAndCopy(srcStat, src, dest, opts, cb)\n  if (destStat && !destStat.isDirectory()) {\n    return cb(new Error(`Cannot overwrite non-directory '${dest}' with directory '${src}'.`))\n  }\n  return copyDir(src, dest, opts, cb)\n}\n\nfunction mkDirAndCopy (srcStat, src, dest, opts, cb) {\n  fs.mkdir(dest, err => {\n    if (err) return cb(err)\n    copyDir(src, dest, opts, err => {\n      if (err) return cb(err)\n      return fs.chmod(dest, srcStat.mode, cb)\n    })\n  })\n}\n\nfunction copyDir (src, dest, opts, cb) {\n  fs.readdir(src, (err, items) => {\n    if (err) return cb(err)\n    return copyDirItems(items, src, dest, opts, cb)\n  })\n}\n\nfunction copyDirItems (items, src, dest, opts, cb) {\n  const item = items.pop()\n  if (!item) return cb()\n  return copyDirItem(items, item, src, dest, opts, cb)\n}\n\nfunction copyDirItem (items, item, src, dest, opts, cb) {\n  const srcItem = path.join(src, item)\n  const destItem = path.join(dest, item)\n  stat.checkPaths(srcItem, destItem, 'copy', (err, stats) => {\n    if (err) return cb(err)\n    const { destStat } = stats\n    startCopy(destStat, srcItem, destItem, opts, err => {\n      if (err) return cb(err)\n      return copyDirItems(items, src, dest, opts, cb)\n    })\n  })\n}\n\nfunction onLink (destStat, src, dest, opts, cb) {\n  fs.readlink(src, (err, resolvedSrc) => {\n    if (err) return cb(err)\n    if (opts.dereference) {\n      resolvedSrc = path.resolve(process.cwd(), resolvedSrc)\n    }\n\n    if (!destStat) {\n      return fs.symlink(resolvedSrc, dest, cb)\n    } else {\n      fs.readlink(dest, (err, resolvedDest) => {\n        if (err) {\n          // dest exists and is a regular file or directory,\n          // Windows may throw UNKNOWN error. If dest already exists,\n          // fs throws error anyway, so no need to guard against it here.\n          if (err.code === 'EINVAL' || err.code === 'UNKNOWN') return fs.symlink(resolvedSrc, dest, cb)\n          return cb(err)\n        }\n        if (opts.dereference) {\n          resolvedDest = path.resolve(process.cwd(), resolvedDest)\n        }\n        if (stat.isSrcSubdir(resolvedSrc, resolvedDest)) {\n          return cb(new Error(`Cannot copy '${resolvedSrc}' to a subdirectory of itself, '${resolvedDest}'.`))\n        }\n\n        // do not copy if src is a subdir of dest since unlinking\n        // dest in this case would result in removing src contents\n        // and therefore a broken symlink would be created.\n        if (destStat.isDirectory() && stat.isSrcSubdir(resolvedDest, resolvedSrc)) {\n          return cb(new Error(`Cannot overwrite '${resolvedDest}' with '${resolvedSrc}'.`))\n        }\n        return copyLink(resolvedSrc, dest, cb)\n      })\n    }\n  })\n}\n\nfunction copyLink (resolvedSrc, dest, cb) {\n  fs.unlink(dest, err => {\n    if (err) return cb(err)\n    return fs.symlink(resolvedSrc, dest, cb)\n  })\n}\n\nmodule.exports = copy\n\n\n//# sourceURL=./node_modules/fs-extra/lib/copy/copy.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/copy/index.js":
/*!*************************************************!*\
  !*** ./node_modules/fs-extra/lib/copy/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nmodule.exports = {\n  copy: u(__webpack_require__(/*! ./copy */ \"./node_modules/fs-extra/lib/copy/copy.js\"))\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/copy/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/empty/index.js":
/*!**************************************************!*\
  !*** ./node_modules/fs-extra/lib/empty/index.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst mkdir = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\")\nconst remove = __webpack_require__(/*! ../remove */ \"./node_modules/fs-extra/lib/remove/index.js\")\n\nconst emptyDir = u(function emptyDir (dir, callback) {\n  callback = callback || function () {}\n  fs.readdir(dir, (err, items) => {\n    if (err) return mkdir.mkdirs(dir, callback)\n\n    items = items.map(item => path.join(dir, item))\n\n    deleteItem()\n\n    function deleteItem () {\n      const item = items.pop()\n      if (!item) return callback()\n      remove.remove(item, err => {\n        if (err) return callback(err)\n        deleteItem()\n      })\n    }\n  })\n})\n\nfunction emptyDirSync (dir) {\n  let items\n  try {\n    items = fs.readdirSync(dir)\n  } catch (err) {\n    return mkdir.mkdirsSync(dir)\n  }\n\n  items.forEach(item => {\n    item = path.join(dir, item)\n    remove.removeSync(item)\n  })\n}\n\nmodule.exports = {\n  emptyDirSync,\n  emptydirSync: emptyDirSync,\n  emptyDir,\n  emptydir: emptyDir\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/empty/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/ensure/file.js":
/*!**************************************************!*\
  !*** ./node_modules/fs-extra/lib/ensure/file.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst path = __webpack_require__(/*! path */ \"path\")\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst mkdir = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\")\nconst pathExists = __webpack_require__(/*! ../path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\").pathExists\n\nfunction createFile (file, callback) {\n  function makeFile () {\n    fs.writeFile(file, '', err => {\n      if (err) return callback(err)\n      callback()\n    })\n  }\n\n  fs.stat(file, (err, stats) => { // eslint-disable-line handle-callback-err\n    if (!err && stats.isFile()) return callback()\n    const dir = path.dirname(file)\n    pathExists(dir, (err, dirExists) => {\n      if (err) return callback(err)\n      if (dirExists) return makeFile()\n      mkdir.mkdirs(dir, err => {\n        if (err) return callback(err)\n        makeFile()\n      })\n    })\n  })\n}\n\nfunction createFileSync (file) {\n  let stats\n  try {\n    stats = fs.statSync(file)\n  } catch (e) {}\n  if (stats && stats.isFile()) return\n\n  const dir = path.dirname(file)\n  if (!fs.existsSync(dir)) {\n    mkdir.mkdirsSync(dir)\n  }\n\n  fs.writeFileSync(file, '')\n}\n\nmodule.exports = {\n  createFile: u(createFile),\n  createFileSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/ensure/file.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/ensure/index.js":
/*!***************************************************!*\
  !*** ./node_modules/fs-extra/lib/ensure/index.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst file = __webpack_require__(/*! ./file */ \"./node_modules/fs-extra/lib/ensure/file.js\")\nconst link = __webpack_require__(/*! ./link */ \"./node_modules/fs-extra/lib/ensure/link.js\")\nconst symlink = __webpack_require__(/*! ./symlink */ \"./node_modules/fs-extra/lib/ensure/symlink.js\")\n\nmodule.exports = {\n  // file\n  createFile: file.createFile,\n  createFileSync: file.createFileSync,\n  ensureFile: file.createFile,\n  ensureFileSync: file.createFileSync,\n  // link\n  createLink: link.createLink,\n  createLinkSync: link.createLinkSync,\n  ensureLink: link.createLink,\n  ensureLinkSync: link.createLinkSync,\n  // symlink\n  createSymlink: symlink.createSymlink,\n  createSymlinkSync: symlink.createSymlinkSync,\n  ensureSymlink: symlink.createSymlink,\n  ensureSymlinkSync: symlink.createSymlinkSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/ensure/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/ensure/link.js":
/*!**************************************************!*\
  !*** ./node_modules/fs-extra/lib/ensure/link.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst path = __webpack_require__(/*! path */ \"path\")\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst mkdir = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\")\nconst pathExists = __webpack_require__(/*! ../path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\").pathExists\n\nfunction createLink (srcpath, dstpath, callback) {\n  function makeLink (srcpath, dstpath) {\n    fs.link(srcpath, dstpath, err => {\n      if (err) return callback(err)\n      callback(null)\n    })\n  }\n\n  pathExists(dstpath, (err, destinationExists) => {\n    if (err) return callback(err)\n    if (destinationExists) return callback(null)\n    fs.lstat(srcpath, (err) => {\n      if (err) {\n        err.message = err.message.replace('lstat', 'ensureLink')\n        return callback(err)\n      }\n\n      const dir = path.dirname(dstpath)\n      pathExists(dir, (err, dirExists) => {\n        if (err) return callback(err)\n        if (dirExists) return makeLink(srcpath, dstpath)\n        mkdir.mkdirs(dir, err => {\n          if (err) return callback(err)\n          makeLink(srcpath, dstpath)\n        })\n      })\n    })\n  })\n}\n\nfunction createLinkSync (srcpath, dstpath) {\n  const destinationExists = fs.existsSync(dstpath)\n  if (destinationExists) return undefined\n\n  try {\n    fs.lstatSync(srcpath)\n  } catch (err) {\n    err.message = err.message.replace('lstat', 'ensureLink')\n    throw err\n  }\n\n  const dir = path.dirname(dstpath)\n  const dirExists = fs.existsSync(dir)\n  if (dirExists) return fs.linkSync(srcpath, dstpath)\n  mkdir.mkdirsSync(dir)\n\n  return fs.linkSync(srcpath, dstpath)\n}\n\nmodule.exports = {\n  createLink: u(createLink),\n  createLinkSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/ensure/link.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/ensure/symlink-paths.js":
/*!***********************************************************!*\
  !*** ./node_modules/fs-extra/lib/ensure/symlink-paths.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst path = __webpack_require__(/*! path */ \"path\")\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst pathExists = __webpack_require__(/*! ../path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\").pathExists\n\n/**\n * Function that returns two types of paths, one relative to symlink, and one\n * relative to the current working directory. Checks if path is absolute or\n * relative. If the path is relative, this function checks if the path is\n * relative to symlink or relative to current working directory. This is an\n * initiative to find a smarter `srcpath` to supply when building symlinks.\n * This allows you to determine which path to use out of one of three possible\n * types of source paths. The first is an absolute path. This is detected by\n * `path.isAbsolute()`. When an absolute path is provided, it is checked to\n * see if it exists. If it does it's used, if not an error is returned\n * (callback)/ thrown (sync). The other two options for `srcpath` are a\n * relative url. By default Node's `fs.symlink` works by creating a symlink\n * using `dstpath` and expects the `srcpath` to be relative to the newly\n * created symlink. If you provide a `srcpath` that does not exist on the file\n * system it results in a broken symlink. To minimize this, the function\n * checks to see if the 'relative to symlink' source file exists, and if it\n * does it will use it. If it does not, it checks if there's a file that\n * exists that is relative to the current working directory, if does its used.\n * This preserves the expectations of the original fs.symlink spec and adds\n * the ability to pass in `relative to current working direcotry` paths.\n */\n\nfunction symlinkPaths (srcpath, dstpath, callback) {\n  if (path.isAbsolute(srcpath)) {\n    return fs.lstat(srcpath, (err) => {\n      if (err) {\n        err.message = err.message.replace('lstat', 'ensureSymlink')\n        return callback(err)\n      }\n      return callback(null, {\n        'toCwd': srcpath,\n        'toDst': srcpath\n      })\n    })\n  } else {\n    const dstdir = path.dirname(dstpath)\n    const relativeToDst = path.join(dstdir, srcpath)\n    return pathExists(relativeToDst, (err, exists) => {\n      if (err) return callback(err)\n      if (exists) {\n        return callback(null, {\n          'toCwd': relativeToDst,\n          'toDst': srcpath\n        })\n      } else {\n        return fs.lstat(srcpath, (err) => {\n          if (err) {\n            err.message = err.message.replace('lstat', 'ensureSymlink')\n            return callback(err)\n          }\n          return callback(null, {\n            'toCwd': srcpath,\n            'toDst': path.relative(dstdir, srcpath)\n          })\n        })\n      }\n    })\n  }\n}\n\nfunction symlinkPathsSync (srcpath, dstpath) {\n  let exists\n  if (path.isAbsolute(srcpath)) {\n    exists = fs.existsSync(srcpath)\n    if (!exists) throw new Error('absolute srcpath does not exist')\n    return {\n      'toCwd': srcpath,\n      'toDst': srcpath\n    }\n  } else {\n    const dstdir = path.dirname(dstpath)\n    const relativeToDst = path.join(dstdir, srcpath)\n    exists = fs.existsSync(relativeToDst)\n    if (exists) {\n      return {\n        'toCwd': relativeToDst,\n        'toDst': srcpath\n      }\n    } else {\n      exists = fs.existsSync(srcpath)\n      if (!exists) throw new Error('relative srcpath does not exist')\n      return {\n        'toCwd': srcpath,\n        'toDst': path.relative(dstdir, srcpath)\n      }\n    }\n  }\n}\n\nmodule.exports = {\n  symlinkPaths,\n  symlinkPathsSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/ensure/symlink-paths.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/ensure/symlink-type.js":
/*!**********************************************************!*\
  !*** ./node_modules/fs-extra/lib/ensure/symlink-type.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\n\nfunction symlinkType (srcpath, type, callback) {\n  callback = (typeof type === 'function') ? type : callback\n  type = (typeof type === 'function') ? false : type\n  if (type) return callback(null, type)\n  fs.lstat(srcpath, (err, stats) => {\n    if (err) return callback(null, 'file')\n    type = (stats && stats.isDirectory()) ? 'dir' : 'file'\n    callback(null, type)\n  })\n}\n\nfunction symlinkTypeSync (srcpath, type) {\n  let stats\n\n  if (type) return type\n  try {\n    stats = fs.lstatSync(srcpath)\n  } catch (e) {\n    return 'file'\n  }\n  return (stats && stats.isDirectory()) ? 'dir' : 'file'\n}\n\nmodule.exports = {\n  symlinkType,\n  symlinkTypeSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/ensure/symlink-type.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/ensure/symlink.js":
/*!*****************************************************!*\
  !*** ./node_modules/fs-extra/lib/ensure/symlink.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst path = __webpack_require__(/*! path */ \"path\")\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst _mkdirs = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\")\nconst mkdirs = _mkdirs.mkdirs\nconst mkdirsSync = _mkdirs.mkdirsSync\n\nconst _symlinkPaths = __webpack_require__(/*! ./symlink-paths */ \"./node_modules/fs-extra/lib/ensure/symlink-paths.js\")\nconst symlinkPaths = _symlinkPaths.symlinkPaths\nconst symlinkPathsSync = _symlinkPaths.symlinkPathsSync\n\nconst _symlinkType = __webpack_require__(/*! ./symlink-type */ \"./node_modules/fs-extra/lib/ensure/symlink-type.js\")\nconst symlinkType = _symlinkType.symlinkType\nconst symlinkTypeSync = _symlinkType.symlinkTypeSync\n\nconst pathExists = __webpack_require__(/*! ../path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\").pathExists\n\nfunction createSymlink (srcpath, dstpath, type, callback) {\n  callback = (typeof type === 'function') ? type : callback\n  type = (typeof type === 'function') ? false : type\n\n  pathExists(dstpath, (err, destinationExists) => {\n    if (err) return callback(err)\n    if (destinationExists) return callback(null)\n    symlinkPaths(srcpath, dstpath, (err, relative) => {\n      if (err) return callback(err)\n      srcpath = relative.toDst\n      symlinkType(relative.toCwd, type, (err, type) => {\n        if (err) return callback(err)\n        const dir = path.dirname(dstpath)\n        pathExists(dir, (err, dirExists) => {\n          if (err) return callback(err)\n          if (dirExists) return fs.symlink(srcpath, dstpath, type, callback)\n          mkdirs(dir, err => {\n            if (err) return callback(err)\n            fs.symlink(srcpath, dstpath, type, callback)\n          })\n        })\n      })\n    })\n  })\n}\n\nfunction createSymlinkSync (srcpath, dstpath, type) {\n  const destinationExists = fs.existsSync(dstpath)\n  if (destinationExists) return undefined\n\n  const relative = symlinkPathsSync(srcpath, dstpath)\n  srcpath = relative.toDst\n  type = symlinkTypeSync(relative.toCwd, type)\n  const dir = path.dirname(dstpath)\n  const exists = fs.existsSync(dir)\n  if (exists) return fs.symlinkSync(srcpath, dstpath, type)\n  mkdirsSync(dir)\n  return fs.symlinkSync(srcpath, dstpath, type)\n}\n\nmodule.exports = {\n  createSymlink: u(createSymlink),\n  createSymlinkSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/ensure/symlink.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/fs/index.js":
/*!***********************************************!*\
  !*** ./node_modules/fs-extra/lib/fs/index.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n// This is adapted from https://github.com/normalize/mz\n// Copyright (c) 2014-2016 Jonathan Ong me@jongleberry.com and Contributors\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\n\nconst api = [\n  'access',\n  'appendFile',\n  'chmod',\n  'chown',\n  'close',\n  'copyFile',\n  'fchmod',\n  'fchown',\n  'fdatasync',\n  'fstat',\n  'fsync',\n  'ftruncate',\n  'futimes',\n  'lchown',\n  'lchmod',\n  'link',\n  'lstat',\n  'mkdir',\n  'mkdtemp',\n  'open',\n  'readFile',\n  'readdir',\n  'readlink',\n  'realpath',\n  'rename',\n  'rmdir',\n  'stat',\n  'symlink',\n  'truncate',\n  'unlink',\n  'utimes',\n  'writeFile'\n].filter(key => {\n  // Some commands are not available on some systems. Ex:\n  // fs.copyFile was added in Node.js v8.5.0\n  // fs.mkdtemp was added in Node.js v5.10.0\n  // fs.lchown is not available on at least some Linux\n  return typeof fs[key] === 'function'\n})\n\n// Export all keys:\nObject.keys(fs).forEach(key => {\n  if (key === 'promises') {\n    // fs.promises is a getter property that triggers ExperimentalWarning\n    // Don't re-export it here, the getter is defined in \"lib/index.js\"\n    return\n  }\n  exports[key] = fs[key]\n})\n\n// Universalify async methods:\napi.forEach(method => {\n  exports[method] = u(fs[method])\n})\n\n// We differ from mz/fs in that we still ship the old, broken, fs.exists()\n// since we are a drop-in replacement for the native module\nexports.exists = function (filename, callback) {\n  if (typeof callback === 'function') {\n    return fs.exists(filename, callback)\n  }\n  return new Promise(resolve => {\n    return fs.exists(filename, resolve)\n  })\n}\n\n// fs.read() & fs.write need special treatment due to multiple callback args\n\nexports.read = function (fd, buffer, offset, length, position, callback) {\n  if (typeof callback === 'function') {\n    return fs.read(fd, buffer, offset, length, position, callback)\n  }\n  return new Promise((resolve, reject) => {\n    fs.read(fd, buffer, offset, length, position, (err, bytesRead, buffer) => {\n      if (err) return reject(err)\n      resolve({ bytesRead, buffer })\n    })\n  })\n}\n\n// Function signature can be\n// fs.write(fd, buffer[, offset[, length[, position]]], callback)\n// OR\n// fs.write(fd, string[, position[, encoding]], callback)\n// We need to handle both cases, so we use ...args\nexports.write = function (fd, buffer, ...args) {\n  if (typeof args[args.length - 1] === 'function') {\n    return fs.write(fd, buffer, ...args)\n  }\n\n  return new Promise((resolve, reject) => {\n    fs.write(fd, buffer, ...args, (err, bytesWritten, buffer) => {\n      if (err) return reject(err)\n      resolve({ bytesWritten, buffer })\n    })\n  })\n}\n\n// fs.realpath.native only available in Node v9.2+\nif (typeof fs.realpath.native === 'function') {\n  exports.realpath.native = u(fs.realpath.native)\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/fs/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/index.js":
/*!********************************************!*\
  !*** ./node_modules/fs-extra/lib/index.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nmodule.exports = Object.assign(\n  {},\n  // Export promiseified graceful-fs:\n  __webpack_require__(/*! ./fs */ \"./node_modules/fs-extra/lib/fs/index.js\"),\n  // Export extra methods:\n  __webpack_require__(/*! ./copy-sync */ \"./node_modules/fs-extra/lib/copy-sync/index.js\"),\n  __webpack_require__(/*! ./copy */ \"./node_modules/fs-extra/lib/copy/index.js\"),\n  __webpack_require__(/*! ./empty */ \"./node_modules/fs-extra/lib/empty/index.js\"),\n  __webpack_require__(/*! ./ensure */ \"./node_modules/fs-extra/lib/ensure/index.js\"),\n  __webpack_require__(/*! ./json */ \"./node_modules/fs-extra/lib/json/index.js\"),\n  __webpack_require__(/*! ./mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\"),\n  __webpack_require__(/*! ./move-sync */ \"./node_modules/fs-extra/lib/move-sync/index.js\"),\n  __webpack_require__(/*! ./move */ \"./node_modules/fs-extra/lib/move/index.js\"),\n  __webpack_require__(/*! ./output */ \"./node_modules/fs-extra/lib/output/index.js\"),\n  __webpack_require__(/*! ./path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\"),\n  __webpack_require__(/*! ./remove */ \"./node_modules/fs-extra/lib/remove/index.js\")\n)\n\n// Export fs.promises as a getter property so that we don't trigger\n// ExperimentalWarning before fs.promises is actually accessed.\nconst fs = __webpack_require__(/*! fs */ \"fs\")\nif (Object.getOwnPropertyDescriptor(fs, 'promises')) {\n  Object.defineProperty(module.exports, 'promises', {\n    get () { return fs.promises }\n  })\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/json/index.js":
/*!*************************************************!*\
  !*** ./node_modules/fs-extra/lib/json/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst jsonFile = __webpack_require__(/*! ./jsonfile */ \"./node_modules/fs-extra/lib/json/jsonfile.js\")\n\njsonFile.outputJson = u(__webpack_require__(/*! ./output-json */ \"./node_modules/fs-extra/lib/json/output-json.js\"))\njsonFile.outputJsonSync = __webpack_require__(/*! ./output-json-sync */ \"./node_modules/fs-extra/lib/json/output-json-sync.js\")\n// aliases\njsonFile.outputJSON = jsonFile.outputJson\njsonFile.outputJSONSync = jsonFile.outputJsonSync\njsonFile.writeJSON = jsonFile.writeJson\njsonFile.writeJSONSync = jsonFile.writeJsonSync\njsonFile.readJSON = jsonFile.readJson\njsonFile.readJSONSync = jsonFile.readJsonSync\n\nmodule.exports = jsonFile\n\n\n//# sourceURL=./node_modules/fs-extra/lib/json/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/json/jsonfile.js":
/*!****************************************************!*\
  !*** ./node_modules/fs-extra/lib/json/jsonfile.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst jsonFile = __webpack_require__(/*! jsonfile */ \"./node_modules/jsonfile/index.js\")\n\nmodule.exports = {\n  // jsonfile exports\n  readJson: u(jsonFile.readFile),\n  readJsonSync: jsonFile.readFileSync,\n  writeJson: u(jsonFile.writeFile),\n  writeJsonSync: jsonFile.writeFileSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/json/jsonfile.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/json/output-json-sync.js":
/*!************************************************************!*\
  !*** ./node_modules/fs-extra/lib/json/output-json-sync.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst mkdir = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\")\nconst jsonFile = __webpack_require__(/*! ./jsonfile */ \"./node_modules/fs-extra/lib/json/jsonfile.js\")\n\nfunction outputJsonSync (file, data, options) {\n  const dir = path.dirname(file)\n\n  if (!fs.existsSync(dir)) {\n    mkdir.mkdirsSync(dir)\n  }\n\n  jsonFile.writeJsonSync(file, data, options)\n}\n\nmodule.exports = outputJsonSync\n\n\n//# sourceURL=./node_modules/fs-extra/lib/json/output-json-sync.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/json/output-json.js":
/*!*******************************************************!*\
  !*** ./node_modules/fs-extra/lib/json/output-json.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst path = __webpack_require__(/*! path */ \"path\")\nconst mkdir = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\")\nconst pathExists = __webpack_require__(/*! ../path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\").pathExists\nconst jsonFile = __webpack_require__(/*! ./jsonfile */ \"./node_modules/fs-extra/lib/json/jsonfile.js\")\n\nfunction outputJson (file, data, options, callback) {\n  if (typeof options === 'function') {\n    callback = options\n    options = {}\n  }\n\n  const dir = path.dirname(file)\n\n  pathExists(dir, (err, itDoes) => {\n    if (err) return callback(err)\n    if (itDoes) return jsonFile.writeJson(file, data, options, callback)\n\n    mkdir.mkdirs(dir, err => {\n      if (err) return callback(err)\n      jsonFile.writeJson(file, data, options, callback)\n    })\n  })\n}\n\nmodule.exports = outputJson\n\n\n//# sourceURL=./node_modules/fs-extra/lib/json/output-json.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/mkdirs/index.js":
/*!***************************************************!*\
  !*** ./node_modules/fs-extra/lib/mkdirs/index.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst mkdirs = u(__webpack_require__(/*! ./mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/mkdirs.js\"))\nconst mkdirsSync = __webpack_require__(/*! ./mkdirs-sync */ \"./node_modules/fs-extra/lib/mkdirs/mkdirs-sync.js\")\n\nmodule.exports = {\n  mkdirs,\n  mkdirsSync,\n  // alias\n  mkdirp: mkdirs,\n  mkdirpSync: mkdirsSync,\n  ensureDir: mkdirs,\n  ensureDirSync: mkdirsSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/mkdirs/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/mkdirs/mkdirs-sync.js":
/*!*********************************************************!*\
  !*** ./node_modules/fs-extra/lib/mkdirs/mkdirs-sync.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst invalidWin32Path = __webpack_require__(/*! ./win32 */ \"./node_modules/fs-extra/lib/mkdirs/win32.js\").invalidWin32Path\n\nconst o777 = parseInt('0777', 8)\n\nfunction mkdirsSync (p, opts, made) {\n  if (!opts || typeof opts !== 'object') {\n    opts = { mode: opts }\n  }\n\n  let mode = opts.mode\n  const xfs = opts.fs || fs\n\n  if (process.platform === 'win32' && invalidWin32Path(p)) {\n    const errInval = new Error(p + ' contains invalid WIN32 path characters.')\n    errInval.code = 'EINVAL'\n    throw errInval\n  }\n\n  if (mode === undefined) {\n    mode = o777 & (~process.umask())\n  }\n  if (!made) made = null\n\n  p = path.resolve(p)\n\n  try {\n    xfs.mkdirSync(p, mode)\n    made = made || p\n  } catch (err0) {\n    if (err0.code === 'ENOENT') {\n      if (path.dirname(p) === p) throw err0\n      made = mkdirsSync(path.dirname(p), opts, made)\n      mkdirsSync(p, opts, made)\n    } else {\n      // In the case of any other error, just see if there's a dir there\n      // already. If so, then hooray!  If not, then something is borked.\n      let stat\n      try {\n        stat = xfs.statSync(p)\n      } catch (err1) {\n        throw err0\n      }\n      if (!stat.isDirectory()) throw err0\n    }\n  }\n\n  return made\n}\n\nmodule.exports = mkdirsSync\n\n\n//# sourceURL=./node_modules/fs-extra/lib/mkdirs/mkdirs-sync.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/mkdirs/mkdirs.js":
/*!****************************************************!*\
  !*** ./node_modules/fs-extra/lib/mkdirs/mkdirs.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst invalidWin32Path = __webpack_require__(/*! ./win32 */ \"./node_modules/fs-extra/lib/mkdirs/win32.js\").invalidWin32Path\n\nconst o777 = parseInt('0777', 8)\n\nfunction mkdirs (p, opts, callback, made) {\n  if (typeof opts === 'function') {\n    callback = opts\n    opts = {}\n  } else if (!opts || typeof opts !== 'object') {\n    opts = { mode: opts }\n  }\n\n  if (process.platform === 'win32' && invalidWin32Path(p)) {\n    const errInval = new Error(p + ' contains invalid WIN32 path characters.')\n    errInval.code = 'EINVAL'\n    return callback(errInval)\n  }\n\n  let mode = opts.mode\n  const xfs = opts.fs || fs\n\n  if (mode === undefined) {\n    mode = o777 & (~process.umask())\n  }\n  if (!made) made = null\n\n  callback = callback || function () {}\n  p = path.resolve(p)\n\n  xfs.mkdir(p, mode, er => {\n    if (!er) {\n      made = made || p\n      return callback(null, made)\n    }\n    switch (er.code) {\n      case 'ENOENT':\n        if (path.dirname(p) === p) return callback(er)\n        mkdirs(path.dirname(p), opts, (er, made) => {\n          if (er) callback(er, made)\n          else mkdirs(p, opts, callback, made)\n        })\n        break\n\n      // In the case of any other error, just see if there's a dir\n      // there already.  If so, then hooray!  If not, then something\n      // is borked.\n      default:\n        xfs.stat(p, (er2, stat) => {\n          // if the stat fails, then that's super weird.\n          // let the original error be the failure reason.\n          if (er2 || !stat.isDirectory()) callback(er, made)\n          else callback(null, made)\n        })\n        break\n    }\n  })\n}\n\nmodule.exports = mkdirs\n\n\n//# sourceURL=./node_modules/fs-extra/lib/mkdirs/mkdirs.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/mkdirs/win32.js":
/*!***************************************************!*\
  !*** ./node_modules/fs-extra/lib/mkdirs/win32.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst path = __webpack_require__(/*! path */ \"path\")\n\n// get drive on windows\nfunction getRootPath (p) {\n  p = path.normalize(path.resolve(p)).split(path.sep)\n  if (p.length > 0) return p[0]\n  return null\n}\n\n// http://stackoverflow.com/a/62888/10333 contains more accurate\n// TODO: expand to include the rest\nconst INVALID_PATH_CHARS = /[<>:\"|?*]/\n\nfunction invalidWin32Path (p) {\n  const rp = getRootPath(p)\n  p = p.replace(rp, '')\n  return INVALID_PATH_CHARS.test(p)\n}\n\nmodule.exports = {\n  getRootPath,\n  invalidWin32Path\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/mkdirs/win32.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/move-sync/index.js":
/*!******************************************************!*\
  !*** ./node_modules/fs-extra/lib/move-sync/index.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nmodule.exports = {\n  moveSync: __webpack_require__(/*! ./move-sync */ \"./node_modules/fs-extra/lib/move-sync/move-sync.js\")\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/move-sync/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/move-sync/move-sync.js":
/*!**********************************************************!*\
  !*** ./node_modules/fs-extra/lib/move-sync/move-sync.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst copySync = __webpack_require__(/*! ../copy-sync */ \"./node_modules/fs-extra/lib/copy-sync/index.js\").copySync\nconst removeSync = __webpack_require__(/*! ../remove */ \"./node_modules/fs-extra/lib/remove/index.js\").removeSync\nconst mkdirpSync = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\").mkdirpSync\nconst stat = __webpack_require__(/*! ../util/stat */ \"./node_modules/fs-extra/lib/util/stat.js\")\n\nfunction moveSync (src, dest, opts) {\n  opts = opts || {}\n  const overwrite = opts.overwrite || opts.clobber || false\n\n  const { srcStat } = stat.checkPathsSync(src, dest, 'move')\n  stat.checkParentPathsSync(src, srcStat, dest, 'move')\n  mkdirpSync(path.dirname(dest))\n  return doRename(src, dest, overwrite)\n}\n\nfunction doRename (src, dest, overwrite) {\n  if (overwrite) {\n    removeSync(dest)\n    return rename(src, dest, overwrite)\n  }\n  if (fs.existsSync(dest)) throw new Error('dest already exists.')\n  return rename(src, dest, overwrite)\n}\n\nfunction rename (src, dest, overwrite) {\n  try {\n    fs.renameSync(src, dest)\n  } catch (err) {\n    if (err.code !== 'EXDEV') throw err\n    return moveAcrossDevice(src, dest, overwrite)\n  }\n}\n\nfunction moveAcrossDevice (src, dest, overwrite) {\n  const opts = {\n    overwrite,\n    errorOnExist: true\n  }\n  copySync(src, dest, opts)\n  return removeSync(src)\n}\n\nmodule.exports = moveSync\n\n\n//# sourceURL=./node_modules/fs-extra/lib/move-sync/move-sync.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/move/index.js":
/*!*************************************************!*\
  !*** ./node_modules/fs-extra/lib/move/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nmodule.exports = {\n  move: u(__webpack_require__(/*! ./move */ \"./node_modules/fs-extra/lib/move/move.js\"))\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/move/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/move/move.js":
/*!************************************************!*\
  !*** ./node_modules/fs-extra/lib/move/move.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst copy = __webpack_require__(/*! ../copy */ \"./node_modules/fs-extra/lib/copy/index.js\").copy\nconst remove = __webpack_require__(/*! ../remove */ \"./node_modules/fs-extra/lib/remove/index.js\").remove\nconst mkdirp = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\").mkdirp\nconst pathExists = __webpack_require__(/*! ../path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\").pathExists\nconst stat = __webpack_require__(/*! ../util/stat */ \"./node_modules/fs-extra/lib/util/stat.js\")\n\nfunction move (src, dest, opts, cb) {\n  if (typeof opts === 'function') {\n    cb = opts\n    opts = {}\n  }\n\n  const overwrite = opts.overwrite || opts.clobber || false\n\n  stat.checkPaths(src, dest, 'move', (err, stats) => {\n    if (err) return cb(err)\n    const { srcStat } = stats\n    stat.checkParentPaths(src, srcStat, dest, 'move', err => {\n      if (err) return cb(err)\n      mkdirp(path.dirname(dest), err => {\n        if (err) return cb(err)\n        return doRename(src, dest, overwrite, cb)\n      })\n    })\n  })\n}\n\nfunction doRename (src, dest, overwrite, cb) {\n  if (overwrite) {\n    return remove(dest, err => {\n      if (err) return cb(err)\n      return rename(src, dest, overwrite, cb)\n    })\n  }\n  pathExists(dest, (err, destExists) => {\n    if (err) return cb(err)\n    if (destExists) return cb(new Error('dest already exists.'))\n    return rename(src, dest, overwrite, cb)\n  })\n}\n\nfunction rename (src, dest, overwrite, cb) {\n  fs.rename(src, dest, err => {\n    if (!err) return cb()\n    if (err.code !== 'EXDEV') return cb(err)\n    return moveAcrossDevice(src, dest, overwrite, cb)\n  })\n}\n\nfunction moveAcrossDevice (src, dest, overwrite, cb) {\n  const opts = {\n    overwrite,\n    errorOnExist: true\n  }\n  copy(src, dest, opts, err => {\n    if (err) return cb(err)\n    return remove(src, cb)\n  })\n}\n\nmodule.exports = move\n\n\n//# sourceURL=./node_modules/fs-extra/lib/move/move.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/output/index.js":
/*!***************************************************!*\
  !*** ./node_modules/fs-extra/lib/output/index.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst mkdir = __webpack_require__(/*! ../mkdirs */ \"./node_modules/fs-extra/lib/mkdirs/index.js\")\nconst pathExists = __webpack_require__(/*! ../path-exists */ \"./node_modules/fs-extra/lib/path-exists/index.js\").pathExists\n\nfunction outputFile (file, data, encoding, callback) {\n  if (typeof encoding === 'function') {\n    callback = encoding\n    encoding = 'utf8'\n  }\n\n  const dir = path.dirname(file)\n  pathExists(dir, (err, itDoes) => {\n    if (err) return callback(err)\n    if (itDoes) return fs.writeFile(file, data, encoding, callback)\n\n    mkdir.mkdirs(dir, err => {\n      if (err) return callback(err)\n\n      fs.writeFile(file, data, encoding, callback)\n    })\n  })\n}\n\nfunction outputFileSync (file, ...args) {\n  const dir = path.dirname(file)\n  if (fs.existsSync(dir)) {\n    return fs.writeFileSync(file, ...args)\n  }\n  mkdir.mkdirsSync(dir)\n  fs.writeFileSync(file, ...args)\n}\n\nmodule.exports = {\n  outputFile: u(outputFile),\n  outputFileSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/output/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/path-exists/index.js":
/*!********************************************************!*\
  !*** ./node_modules/fs-extra/lib/path-exists/index.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromPromise\nconst fs = __webpack_require__(/*! ../fs */ \"./node_modules/fs-extra/lib/fs/index.js\")\n\nfunction pathExists (path) {\n  return fs.access(path).then(() => true).catch(() => false)\n}\n\nmodule.exports = {\n  pathExists: u(pathExists),\n  pathExistsSync: fs.existsSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/path-exists/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/remove/index.js":
/*!***************************************************!*\
  !*** ./node_modules/fs-extra/lib/remove/index.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst u = __webpack_require__(/*! universalify */ \"./node_modules/universalify/index.js\").fromCallback\nconst rimraf = __webpack_require__(/*! ./rimraf */ \"./node_modules/fs-extra/lib/remove/rimraf.js\")\n\nmodule.exports = {\n  remove: u(rimraf),\n  removeSync: rimraf.sync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/remove/index.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/remove/rimraf.js":
/*!****************************************************!*\
  !*** ./node_modules/fs-extra/lib/remove/rimraf.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\nconst assert = __webpack_require__(/*! assert */ \"assert\")\n\nconst isWindows = (process.platform === 'win32')\n\nfunction defaults (options) {\n  const methods = [\n    'unlink',\n    'chmod',\n    'stat',\n    'lstat',\n    'rmdir',\n    'readdir'\n  ]\n  methods.forEach(m => {\n    options[m] = options[m] || fs[m]\n    m = m + 'Sync'\n    options[m] = options[m] || fs[m]\n  })\n\n  options.maxBusyTries = options.maxBusyTries || 3\n}\n\nfunction rimraf (p, options, cb) {\n  let busyTries = 0\n\n  if (typeof options === 'function') {\n    cb = options\n    options = {}\n  }\n\n  assert(p, 'rimraf: missing path')\n  assert.strictEqual(typeof p, 'string', 'rimraf: path should be a string')\n  assert.strictEqual(typeof cb, 'function', 'rimraf: callback function required')\n  assert(options, 'rimraf: invalid options argument provided')\n  assert.strictEqual(typeof options, 'object', 'rimraf: options should be object')\n\n  defaults(options)\n\n  rimraf_(p, options, function CB (er) {\n    if (er) {\n      if ((er.code === 'EBUSY' || er.code === 'ENOTEMPTY' || er.code === 'EPERM') &&\n          busyTries < options.maxBusyTries) {\n        busyTries++\n        const time = busyTries * 100\n        // try again, with the same exact callback as this one.\n        return setTimeout(() => rimraf_(p, options, CB), time)\n      }\n\n      // already gone\n      if (er.code === 'ENOENT') er = null\n    }\n\n    cb(er)\n  })\n}\n\n// Two possible strategies.\n// 1. Assume it's a file.  unlink it, then do the dir stuff on EPERM or EISDIR\n// 2. Assume it's a directory.  readdir, then do the file stuff on ENOTDIR\n//\n// Both result in an extra syscall when you guess wrong.  However, there\n// are likely far more normal files in the world than directories.  This\n// is based on the assumption that a the average number of files per\n// directory is >= 1.\n//\n// If anyone ever complains about this, then I guess the strategy could\n// be made configurable somehow.  But until then, YAGNI.\nfunction rimraf_ (p, options, cb) {\n  assert(p)\n  assert(options)\n  assert(typeof cb === 'function')\n\n  // sunos lets the root user unlink directories, which is... weird.\n  // so we have to lstat here and make sure it's not a dir.\n  options.lstat(p, (er, st) => {\n    if (er && er.code === 'ENOENT') {\n      return cb(null)\n    }\n\n    // Windows can EPERM on stat.  Life is suffering.\n    if (er && er.code === 'EPERM' && isWindows) {\n      return fixWinEPERM(p, options, er, cb)\n    }\n\n    if (st && st.isDirectory()) {\n      return rmdir(p, options, er, cb)\n    }\n\n    options.unlink(p, er => {\n      if (er) {\n        if (er.code === 'ENOENT') {\n          return cb(null)\n        }\n        if (er.code === 'EPERM') {\n          return (isWindows)\n            ? fixWinEPERM(p, options, er, cb)\n            : rmdir(p, options, er, cb)\n        }\n        if (er.code === 'EISDIR') {\n          return rmdir(p, options, er, cb)\n        }\n      }\n      return cb(er)\n    })\n  })\n}\n\nfunction fixWinEPERM (p, options, er, cb) {\n  assert(p)\n  assert(options)\n  assert(typeof cb === 'function')\n  if (er) {\n    assert(er instanceof Error)\n  }\n\n  options.chmod(p, 0o666, er2 => {\n    if (er2) {\n      cb(er2.code === 'ENOENT' ? null : er)\n    } else {\n      options.stat(p, (er3, stats) => {\n        if (er3) {\n          cb(er3.code === 'ENOENT' ? null : er)\n        } else if (stats.isDirectory()) {\n          rmdir(p, options, er, cb)\n        } else {\n          options.unlink(p, cb)\n        }\n      })\n    }\n  })\n}\n\nfunction fixWinEPERMSync (p, options, er) {\n  let stats\n\n  assert(p)\n  assert(options)\n  if (er) {\n    assert(er instanceof Error)\n  }\n\n  try {\n    options.chmodSync(p, 0o666)\n  } catch (er2) {\n    if (er2.code === 'ENOENT') {\n      return\n    } else {\n      throw er\n    }\n  }\n\n  try {\n    stats = options.statSync(p)\n  } catch (er3) {\n    if (er3.code === 'ENOENT') {\n      return\n    } else {\n      throw er\n    }\n  }\n\n  if (stats.isDirectory()) {\n    rmdirSync(p, options, er)\n  } else {\n    options.unlinkSync(p)\n  }\n}\n\nfunction rmdir (p, options, originalEr, cb) {\n  assert(p)\n  assert(options)\n  if (originalEr) {\n    assert(originalEr instanceof Error)\n  }\n  assert(typeof cb === 'function')\n\n  // try to rmdir first, and only readdir on ENOTEMPTY or EEXIST (SunOS)\n  // if we guessed wrong, and it's not a directory, then\n  // raise the original error.\n  options.rmdir(p, er => {\n    if (er && (er.code === 'ENOTEMPTY' || er.code === 'EEXIST' || er.code === 'EPERM')) {\n      rmkids(p, options, cb)\n    } else if (er && er.code === 'ENOTDIR') {\n      cb(originalEr)\n    } else {\n      cb(er)\n    }\n  })\n}\n\nfunction rmkids (p, options, cb) {\n  assert(p)\n  assert(options)\n  assert(typeof cb === 'function')\n\n  options.readdir(p, (er, files) => {\n    if (er) return cb(er)\n\n    let n = files.length\n    let errState\n\n    if (n === 0) return options.rmdir(p, cb)\n\n    files.forEach(f => {\n      rimraf(path.join(p, f), options, er => {\n        if (errState) {\n          return\n        }\n        if (er) return cb(errState = er)\n        if (--n === 0) {\n          options.rmdir(p, cb)\n        }\n      })\n    })\n  })\n}\n\n// this looks simpler, and is strictly *faster*, but will\n// tie up the JavaScript thread and fail on excessively\n// deep directory trees.\nfunction rimrafSync (p, options) {\n  let st\n\n  options = options || {}\n  defaults(options)\n\n  assert(p, 'rimraf: missing path')\n  assert.strictEqual(typeof p, 'string', 'rimraf: path should be a string')\n  assert(options, 'rimraf: missing options')\n  assert.strictEqual(typeof options, 'object', 'rimraf: options should be object')\n\n  try {\n    st = options.lstatSync(p)\n  } catch (er) {\n    if (er.code === 'ENOENT') {\n      return\n    }\n\n    // Windows can EPERM on stat.  Life is suffering.\n    if (er.code === 'EPERM' && isWindows) {\n      fixWinEPERMSync(p, options, er)\n    }\n  }\n\n  try {\n    // sunos lets the root user unlink directories, which is... weird.\n    if (st && st.isDirectory()) {\n      rmdirSync(p, options, null)\n    } else {\n      options.unlinkSync(p)\n    }\n  } catch (er) {\n    if (er.code === 'ENOENT') {\n      return\n    } else if (er.code === 'EPERM') {\n      return isWindows ? fixWinEPERMSync(p, options, er) : rmdirSync(p, options, er)\n    } else if (er.code !== 'EISDIR') {\n      throw er\n    }\n    rmdirSync(p, options, er)\n  }\n}\n\nfunction rmdirSync (p, options, originalEr) {\n  assert(p)\n  assert(options)\n  if (originalEr) {\n    assert(originalEr instanceof Error)\n  }\n\n  try {\n    options.rmdirSync(p)\n  } catch (er) {\n    if (er.code === 'ENOTDIR') {\n      throw originalEr\n    } else if (er.code === 'ENOTEMPTY' || er.code === 'EEXIST' || er.code === 'EPERM') {\n      rmkidsSync(p, options)\n    } else if (er.code !== 'ENOENT') {\n      throw er\n    }\n  }\n}\n\nfunction rmkidsSync (p, options) {\n  assert(p)\n  assert(options)\n  options.readdirSync(p).forEach(f => rimrafSync(path.join(p, f), options))\n\n  if (isWindows) {\n    // We only end up here once we got ENOTEMPTY at least once, and\n    // at this point, we are guaranteed to have removed all the kids.\n    // So, we know that it won't be ENOENT or ENOTDIR or anything else.\n    // try really hard to delete stuff on windows, because it has a\n    // PROFOUNDLY annoying habit of not closing handles promptly when\n    // files are deleted, resulting in spurious ENOTEMPTY errors.\n    const startTime = Date.now()\n    do {\n      try {\n        const ret = options.rmdirSync(p, options)\n        return ret\n      } catch (er) { }\n    } while (Date.now() - startTime < 500) // give up after 500ms\n  } else {\n    const ret = options.rmdirSync(p, options)\n    return ret\n  }\n}\n\nmodule.exports = rimraf\nrimraf.sync = rimrafSync\n\n\n//# sourceURL=./node_modules/fs-extra/lib/remove/rimraf.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/util/buffer.js":
/*!**************************************************!*\
  !*** ./node_modules/fs-extra/lib/util/buffer.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n/* eslint-disable node/no-deprecated-api */\nmodule.exports = function (size) {\n  if (typeof Buffer.allocUnsafe === 'function') {\n    try {\n      return Buffer.allocUnsafe(size)\n    } catch (e) {\n      return new Buffer(size)\n    }\n  }\n  return new Buffer(size)\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/util/buffer.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/util/stat.js":
/*!************************************************!*\
  !*** ./node_modules/fs-extra/lib/util/stat.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst path = __webpack_require__(/*! path */ \"path\")\n\nconst NODE_VERSION_MAJOR_WITH_BIGINT = 10\nconst NODE_VERSION_MINOR_WITH_BIGINT = 5\nconst NODE_VERSION_PATCH_WITH_BIGINT = 0\nconst nodeVersion = process.versions.node.split('.')\nconst nodeVersionMajor = Number.parseInt(nodeVersion[0], 10)\nconst nodeVersionMinor = Number.parseInt(nodeVersion[1], 10)\nconst nodeVersionPatch = Number.parseInt(nodeVersion[2], 10)\n\nfunction nodeSupportsBigInt () {\n  if (nodeVersionMajor > NODE_VERSION_MAJOR_WITH_BIGINT) {\n    return true\n  } else if (nodeVersionMajor === NODE_VERSION_MAJOR_WITH_BIGINT) {\n    if (nodeVersionMinor > NODE_VERSION_MINOR_WITH_BIGINT) {\n      return true\n    } else if (nodeVersionMinor === NODE_VERSION_MINOR_WITH_BIGINT) {\n      if (nodeVersionPatch >= NODE_VERSION_PATCH_WITH_BIGINT) {\n        return true\n      }\n    }\n  }\n  return false\n}\n\nfunction getStats (src, dest, cb) {\n  if (nodeSupportsBigInt()) {\n    fs.stat(src, { bigint: true }, (err, srcStat) => {\n      if (err) return cb(err)\n      fs.stat(dest, { bigint: true }, (err, destStat) => {\n        if (err) {\n          if (err.code === 'ENOENT') return cb(null, { srcStat, destStat: null })\n          return cb(err)\n        }\n        return cb(null, { srcStat, destStat })\n      })\n    })\n  } else {\n    fs.stat(src, (err, srcStat) => {\n      if (err) return cb(err)\n      fs.stat(dest, (err, destStat) => {\n        if (err) {\n          if (err.code === 'ENOENT') return cb(null, { srcStat, destStat: null })\n          return cb(err)\n        }\n        return cb(null, { srcStat, destStat })\n      })\n    })\n  }\n}\n\nfunction getStatsSync (src, dest) {\n  let srcStat, destStat\n  if (nodeSupportsBigInt()) {\n    srcStat = fs.statSync(src, { bigint: true })\n  } else {\n    srcStat = fs.statSync(src)\n  }\n  try {\n    if (nodeSupportsBigInt()) {\n      destStat = fs.statSync(dest, { bigint: true })\n    } else {\n      destStat = fs.statSync(dest)\n    }\n  } catch (err) {\n    if (err.code === 'ENOENT') return { srcStat, destStat: null }\n    throw err\n  }\n  return { srcStat, destStat }\n}\n\nfunction checkPaths (src, dest, funcName, cb) {\n  getStats(src, dest, (err, stats) => {\n    if (err) return cb(err)\n    const { srcStat, destStat } = stats\n    if (destStat && destStat.ino && destStat.dev && destStat.ino === srcStat.ino && destStat.dev === srcStat.dev) {\n      return cb(new Error('Source and destination must not be the same.'))\n    }\n    if (srcStat.isDirectory() && isSrcSubdir(src, dest)) {\n      return cb(new Error(errMsg(src, dest, funcName)))\n    }\n    return cb(null, { srcStat, destStat })\n  })\n}\n\nfunction checkPathsSync (src, dest, funcName) {\n  const { srcStat, destStat } = getStatsSync(src, dest)\n  if (destStat && destStat.ino && destStat.dev && destStat.ino === srcStat.ino && destStat.dev === srcStat.dev) {\n    throw new Error('Source and destination must not be the same.')\n  }\n  if (srcStat.isDirectory() && isSrcSubdir(src, dest)) {\n    throw new Error(errMsg(src, dest, funcName))\n  }\n  return { srcStat, destStat }\n}\n\n// recursively check if dest parent is a subdirectory of src.\n// It works for all file types including symlinks since it\n// checks the src and dest inodes. It starts from the deepest\n// parent and stops once it reaches the src parent or the root path.\nfunction checkParentPaths (src, srcStat, dest, funcName, cb) {\n  const srcParent = path.resolve(path.dirname(src))\n  const destParent = path.resolve(path.dirname(dest))\n  if (destParent === srcParent || destParent === path.parse(destParent).root) return cb()\n  if (nodeSupportsBigInt()) {\n    fs.stat(destParent, { bigint: true }, (err, destStat) => {\n      if (err) {\n        if (err.code === 'ENOENT') return cb()\n        return cb(err)\n      }\n      if (destStat.ino && destStat.dev && destStat.ino === srcStat.ino && destStat.dev === srcStat.dev) {\n        return cb(new Error(errMsg(src, dest, funcName)))\n      }\n      return checkParentPaths(src, srcStat, destParent, funcName, cb)\n    })\n  } else {\n    fs.stat(destParent, (err, destStat) => {\n      if (err) {\n        if (err.code === 'ENOENT') return cb()\n        return cb(err)\n      }\n      if (destStat.ino && destStat.dev && destStat.ino === srcStat.ino && destStat.dev === srcStat.dev) {\n        return cb(new Error(errMsg(src, dest, funcName)))\n      }\n      return checkParentPaths(src, srcStat, destParent, funcName, cb)\n    })\n  }\n}\n\nfunction checkParentPathsSync (src, srcStat, dest, funcName) {\n  const srcParent = path.resolve(path.dirname(src))\n  const destParent = path.resolve(path.dirname(dest))\n  if (destParent === srcParent || destParent === path.parse(destParent).root) return\n  let destStat\n  try {\n    if (nodeSupportsBigInt()) {\n      destStat = fs.statSync(destParent, { bigint: true })\n    } else {\n      destStat = fs.statSync(destParent)\n    }\n  } catch (err) {\n    if (err.code === 'ENOENT') return\n    throw err\n  }\n  if (destStat.ino && destStat.dev && destStat.ino === srcStat.ino && destStat.dev === srcStat.dev) {\n    throw new Error(errMsg(src, dest, funcName))\n  }\n  return checkParentPathsSync(src, srcStat, destParent, funcName)\n}\n\n// return true if dest is a subdir of src, otherwise false.\n// It only checks the path strings.\nfunction isSrcSubdir (src, dest) {\n  const srcArr = path.resolve(src).split(path.sep).filter(i => i)\n  const destArr = path.resolve(dest).split(path.sep).filter(i => i)\n  return srcArr.reduce((acc, cur, i) => acc && destArr[i] === cur, true)\n}\n\nfunction errMsg (src, dest, funcName) {\n  return `Cannot ${funcName} '${src}' to a subdirectory of itself, '${dest}'.`\n}\n\nmodule.exports = {\n  checkPaths,\n  checkPathsSync,\n  checkParentPaths,\n  checkParentPathsSync,\n  isSrcSubdir\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/util/stat.js");

/***/ }),

/***/ "./node_modules/fs-extra/lib/util/utimes.js":
/*!**************************************************!*\
  !*** ./node_modules/fs-extra/lib/util/utimes.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nconst fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\nconst os = __webpack_require__(/*! os */ \"os\")\nconst path = __webpack_require__(/*! path */ \"path\")\n\n// HFS, ext{2,3}, FAT do not, Node.js v0.10 does not\nfunction hasMillisResSync () {\n  let tmpfile = path.join('millis-test-sync' + Date.now().toString() + Math.random().toString().slice(2))\n  tmpfile = path.join(os.tmpdir(), tmpfile)\n\n  // 550 millis past UNIX epoch\n  const d = new Date(1435410243862)\n  fs.writeFileSync(tmpfile, 'https://github.com/jprichardson/node-fs-extra/pull/141')\n  const fd = fs.openSync(tmpfile, 'r+')\n  fs.futimesSync(fd, d, d)\n  fs.closeSync(fd)\n  return fs.statSync(tmpfile).mtime > 1435410243000\n}\n\nfunction hasMillisRes (callback) {\n  let tmpfile = path.join('millis-test' + Date.now().toString() + Math.random().toString().slice(2))\n  tmpfile = path.join(os.tmpdir(), tmpfile)\n\n  // 550 millis past UNIX epoch\n  const d = new Date(1435410243862)\n  fs.writeFile(tmpfile, 'https://github.com/jprichardson/node-fs-extra/pull/141', err => {\n    if (err) return callback(err)\n    fs.open(tmpfile, 'r+', (err, fd) => {\n      if (err) return callback(err)\n      fs.futimes(fd, d, d, err => {\n        if (err) return callback(err)\n        fs.close(fd, err => {\n          if (err) return callback(err)\n          fs.stat(tmpfile, (err, stats) => {\n            if (err) return callback(err)\n            callback(null, stats.mtime > 1435410243000)\n          })\n        })\n      })\n    })\n  })\n}\n\nfunction timeRemoveMillis (timestamp) {\n  if (typeof timestamp === 'number') {\n    return Math.floor(timestamp / 1000) * 1000\n  } else if (timestamp instanceof Date) {\n    return new Date(Math.floor(timestamp.getTime() / 1000) * 1000)\n  } else {\n    throw new Error('fs-extra: timeRemoveMillis() unknown parameter type')\n  }\n}\n\nfunction utimesMillis (path, atime, mtime, callback) {\n  // if (!HAS_MILLIS_RES) return fs.utimes(path, atime, mtime, callback)\n  fs.open(path, 'r+', (err, fd) => {\n    if (err) return callback(err)\n    fs.futimes(fd, atime, mtime, futimesErr => {\n      fs.close(fd, closeErr => {\n        if (callback) callback(futimesErr || closeErr)\n      })\n    })\n  })\n}\n\nfunction utimesMillisSync (path, atime, mtime) {\n  const fd = fs.openSync(path, 'r+')\n  fs.futimesSync(fd, atime, mtime)\n  return fs.closeSync(fd)\n}\n\nmodule.exports = {\n  hasMillisRes,\n  hasMillisResSync,\n  timeRemoveMillis,\n  utimesMillis,\n  utimesMillisSync\n}\n\n\n//# sourceURL=./node_modules/fs-extra/lib/util/utimes.js");

/***/ }),

/***/ "./node_modules/graceful-fs/clone.js":
/*!*******************************************!*\
  !*** ./node_modules/graceful-fs/clone.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nmodule.exports = clone\n\nfunction clone (obj) {\n  if (obj === null || typeof obj !== 'object')\n    return obj\n\n  if (obj instanceof Object)\n    var copy = { __proto__: obj.__proto__ }\n  else\n    var copy = Object.create(null)\n\n  Object.getOwnPropertyNames(obj).forEach(function (key) {\n    Object.defineProperty(copy, key, Object.getOwnPropertyDescriptor(obj, key))\n  })\n\n  return copy\n}\n\n\n//# sourceURL=./node_modules/graceful-fs/clone.js");

/***/ }),

/***/ "./node_modules/graceful-fs/graceful-fs.js":
/*!*************************************************!*\
  !*** ./node_modules/graceful-fs/graceful-fs.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var fs = __webpack_require__(/*! fs */ \"fs\")\nvar polyfills = __webpack_require__(/*! ./polyfills.js */ \"./node_modules/graceful-fs/polyfills.js\")\nvar legacy = __webpack_require__(/*! ./legacy-streams.js */ \"./node_modules/graceful-fs/legacy-streams.js\")\nvar clone = __webpack_require__(/*! ./clone.js */ \"./node_modules/graceful-fs/clone.js\")\n\nvar util = __webpack_require__(/*! util */ \"util\")\n\n/* istanbul ignore next - node 0.x polyfill */\nvar gracefulQueue\nvar previousSymbol\n\n/* istanbul ignore else - node 0.x polyfill */\nif (typeof Symbol === 'function' && typeof Symbol.for === 'function') {\n  gracefulQueue = Symbol.for('graceful-fs.queue')\n  // This is used in testing by future versions\n  previousSymbol = Symbol.for('graceful-fs.previous')\n} else {\n  gracefulQueue = '___graceful-fs.queue'\n  previousSymbol = '___graceful-fs.previous'\n}\n\nfunction noop () {}\n\nvar debug = noop\nif (util.debuglog)\n  debug = util.debuglog('gfs4')\nelse if (/\\bgfs4\\b/i.test(process.env.NODE_DEBUG || ''))\n  debug = function() {\n    var m = util.format.apply(util, arguments)\n    m = 'GFS4: ' + m.split(/\\n/).join('\\nGFS4: ')\n    console.error(m)\n  }\n\n// Once time initialization\nif (!global[gracefulQueue]) {\n  // This queue can be shared by multiple loaded instances\n  var queue = []\n  Object.defineProperty(global, gracefulQueue, {\n    get: function() {\n      return queue\n    }\n  })\n\n  // Patch fs.close/closeSync to shared queue version, because we need\n  // to retry() whenever a close happens *anywhere* in the program.\n  // This is essential when multiple graceful-fs instances are\n  // in play at the same time.\n  fs.close = (function (fs$close) {\n    function close (fd, cb) {\n      return fs$close.call(fs, fd, function (err) {\n        // This function uses the graceful-fs shared queue\n        if (!err) {\n          retry()\n        }\n\n        if (typeof cb === 'function')\n          cb.apply(this, arguments)\n      })\n    }\n\n    Object.defineProperty(close, previousSymbol, {\n      value: fs$close\n    })\n    return close\n  })(fs.close)\n\n  fs.closeSync = (function (fs$closeSync) {\n    function closeSync (fd) {\n      // This function uses the graceful-fs shared queue\n      fs$closeSync.apply(fs, arguments)\n      retry()\n    }\n\n    Object.defineProperty(closeSync, previousSymbol, {\n      value: fs$closeSync\n    })\n    return closeSync\n  })(fs.closeSync)\n\n  if (/\\bgfs4\\b/i.test(process.env.NODE_DEBUG || '')) {\n    process.on('exit', function() {\n      debug(global[gracefulQueue])\n      __webpack_require__(/*! assert */ \"assert\").equal(global[gracefulQueue].length, 0)\n    })\n  }\n}\n\nmodule.exports = patch(clone(fs))\nif (process.env.TEST_GRACEFUL_FS_GLOBAL_PATCH && !fs.__patched) {\n    module.exports = patch(fs)\n    fs.__patched = true;\n}\n\nfunction patch (fs) {\n  // Everything that references the open() function needs to be in here\n  polyfills(fs)\n  fs.gracefulify = patch\n\n  fs.createReadStream = createReadStream\n  fs.createWriteStream = createWriteStream\n  var fs$readFile = fs.readFile\n  fs.readFile = readFile\n  function readFile (path, options, cb) {\n    if (typeof options === 'function')\n      cb = options, options = null\n\n    return go$readFile(path, options, cb)\n\n    function go$readFile (path, options, cb) {\n      return fs$readFile(path, options, function (err) {\n        if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))\n          enqueue([go$readFile, [path, options, cb]])\n        else {\n          if (typeof cb === 'function')\n            cb.apply(this, arguments)\n          retry()\n        }\n      })\n    }\n  }\n\n  var fs$writeFile = fs.writeFile\n  fs.writeFile = writeFile\n  function writeFile (path, data, options, cb) {\n    if (typeof options === 'function')\n      cb = options, options = null\n\n    return go$writeFile(path, data, options, cb)\n\n    function go$writeFile (path, data, options, cb) {\n      return fs$writeFile(path, data, options, function (err) {\n        if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))\n          enqueue([go$writeFile, [path, data, options, cb]])\n        else {\n          if (typeof cb === 'function')\n            cb.apply(this, arguments)\n          retry()\n        }\n      })\n    }\n  }\n\n  var fs$appendFile = fs.appendFile\n  if (fs$appendFile)\n    fs.appendFile = appendFile\n  function appendFile (path, data, options, cb) {\n    if (typeof options === 'function')\n      cb = options, options = null\n\n    return go$appendFile(path, data, options, cb)\n\n    function go$appendFile (path, data, options, cb) {\n      return fs$appendFile(path, data, options, function (err) {\n        if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))\n          enqueue([go$appendFile, [path, data, options, cb]])\n        else {\n          if (typeof cb === 'function')\n            cb.apply(this, arguments)\n          retry()\n        }\n      })\n    }\n  }\n\n  var fs$readdir = fs.readdir\n  fs.readdir = readdir\n  function readdir (path, options, cb) {\n    var args = [path]\n    if (typeof options !== 'function') {\n      args.push(options)\n    } else {\n      cb = options\n    }\n    args.push(go$readdir$cb)\n\n    return go$readdir(args)\n\n    function go$readdir$cb (err, files) {\n      if (files && files.sort)\n        files.sort()\n\n      if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))\n        enqueue([go$readdir, [args]])\n\n      else {\n        if (typeof cb === 'function')\n          cb.apply(this, arguments)\n        retry()\n      }\n    }\n  }\n\n  function go$readdir (args) {\n    return fs$readdir.apply(fs, args)\n  }\n\n  if (process.version.substr(0, 4) === 'v0.8') {\n    var legStreams = legacy(fs)\n    ReadStream = legStreams.ReadStream\n    WriteStream = legStreams.WriteStream\n  }\n\n  var fs$ReadStream = fs.ReadStream\n  if (fs$ReadStream) {\n    ReadStream.prototype = Object.create(fs$ReadStream.prototype)\n    ReadStream.prototype.open = ReadStream$open\n  }\n\n  var fs$WriteStream = fs.WriteStream\n  if (fs$WriteStream) {\n    WriteStream.prototype = Object.create(fs$WriteStream.prototype)\n    WriteStream.prototype.open = WriteStream$open\n  }\n\n  Object.defineProperty(fs, 'ReadStream', {\n    get: function () {\n      return ReadStream\n    },\n    set: function (val) {\n      ReadStream = val\n    },\n    enumerable: true,\n    configurable: true\n  })\n  Object.defineProperty(fs, 'WriteStream', {\n    get: function () {\n      return WriteStream\n    },\n    set: function (val) {\n      WriteStream = val\n    },\n    enumerable: true,\n    configurable: true\n  })\n\n  // legacy names\n  var FileReadStream = ReadStream\n  Object.defineProperty(fs, 'FileReadStream', {\n    get: function () {\n      return FileReadStream\n    },\n    set: function (val) {\n      FileReadStream = val\n    },\n    enumerable: true,\n    configurable: true\n  })\n  var FileWriteStream = WriteStream\n  Object.defineProperty(fs, 'FileWriteStream', {\n    get: function () {\n      return FileWriteStream\n    },\n    set: function (val) {\n      FileWriteStream = val\n    },\n    enumerable: true,\n    configurable: true\n  })\n\n  function ReadStream (path, options) {\n    if (this instanceof ReadStream)\n      return fs$ReadStream.apply(this, arguments), this\n    else\n      return ReadStream.apply(Object.create(ReadStream.prototype), arguments)\n  }\n\n  function ReadStream$open () {\n    var that = this\n    open(that.path, that.flags, that.mode, function (err, fd) {\n      if (err) {\n        if (that.autoClose)\n          that.destroy()\n\n        that.emit('error', err)\n      } else {\n        that.fd = fd\n        that.emit('open', fd)\n        that.read()\n      }\n    })\n  }\n\n  function WriteStream (path, options) {\n    if (this instanceof WriteStream)\n      return fs$WriteStream.apply(this, arguments), this\n    else\n      return WriteStream.apply(Object.create(WriteStream.prototype), arguments)\n  }\n\n  function WriteStream$open () {\n    var that = this\n    open(that.path, that.flags, that.mode, function (err, fd) {\n      if (err) {\n        that.destroy()\n        that.emit('error', err)\n      } else {\n        that.fd = fd\n        that.emit('open', fd)\n      }\n    })\n  }\n\n  function createReadStream (path, options) {\n    return new fs.ReadStream(path, options)\n  }\n\n  function createWriteStream (path, options) {\n    return new fs.WriteStream(path, options)\n  }\n\n  var fs$open = fs.open\n  fs.open = open\n  function open (path, flags, mode, cb) {\n    if (typeof mode === 'function')\n      cb = mode, mode = null\n\n    return go$open(path, flags, mode, cb)\n\n    function go$open (path, flags, mode, cb) {\n      return fs$open(path, flags, mode, function (err, fd) {\n        if (err && (err.code === 'EMFILE' || err.code === 'ENFILE'))\n          enqueue([go$open, [path, flags, mode, cb]])\n        else {\n          if (typeof cb === 'function')\n            cb.apply(this, arguments)\n          retry()\n        }\n      })\n    }\n  }\n\n  return fs\n}\n\nfunction enqueue (elem) {\n  debug('ENQUEUE', elem[0].name, elem[1])\n  global[gracefulQueue].push(elem)\n}\n\nfunction retry () {\n  var elem = global[gracefulQueue].shift()\n  if (elem) {\n    debug('RETRY', elem[0].name, elem[1])\n    elem[0].apply(null, elem[1])\n  }\n}\n\n\n//# sourceURL=./node_modules/graceful-fs/graceful-fs.js");

/***/ }),

/***/ "./node_modules/graceful-fs/legacy-streams.js":
/*!****************************************************!*\
  !*** ./node_modules/graceful-fs/legacy-streams.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var Stream = __webpack_require__(/*! stream */ \"stream\").Stream\n\nmodule.exports = legacy\n\nfunction legacy (fs) {\n  return {\n    ReadStream: ReadStream,\n    WriteStream: WriteStream\n  }\n\n  function ReadStream (path, options) {\n    if (!(this instanceof ReadStream)) return new ReadStream(path, options);\n\n    Stream.call(this);\n\n    var self = this;\n\n    this.path = path;\n    this.fd = null;\n    this.readable = true;\n    this.paused = false;\n\n    this.flags = 'r';\n    this.mode = 438; /*=0666*/\n    this.bufferSize = 64 * 1024;\n\n    options = options || {};\n\n    // Mixin options into this\n    var keys = Object.keys(options);\n    for (var index = 0, length = keys.length; index < length; index++) {\n      var key = keys[index];\n      this[key] = options[key];\n    }\n\n    if (this.encoding) this.setEncoding(this.encoding);\n\n    if (this.start !== undefined) {\n      if ('number' !== typeof this.start) {\n        throw TypeError('start must be a Number');\n      }\n      if (this.end === undefined) {\n        this.end = Infinity;\n      } else if ('number' !== typeof this.end) {\n        throw TypeError('end must be a Number');\n      }\n\n      if (this.start > this.end) {\n        throw new Error('start must be <= end');\n      }\n\n      this.pos = this.start;\n    }\n\n    if (this.fd !== null) {\n      process.nextTick(function() {\n        self._read();\n      });\n      return;\n    }\n\n    fs.open(this.path, this.flags, this.mode, function (err, fd) {\n      if (err) {\n        self.emit('error', err);\n        self.readable = false;\n        return;\n      }\n\n      self.fd = fd;\n      self.emit('open', fd);\n      self._read();\n    })\n  }\n\n  function WriteStream (path, options) {\n    if (!(this instanceof WriteStream)) return new WriteStream(path, options);\n\n    Stream.call(this);\n\n    this.path = path;\n    this.fd = null;\n    this.writable = true;\n\n    this.flags = 'w';\n    this.encoding = 'binary';\n    this.mode = 438; /*=0666*/\n    this.bytesWritten = 0;\n\n    options = options || {};\n\n    // Mixin options into this\n    var keys = Object.keys(options);\n    for (var index = 0, length = keys.length; index < length; index++) {\n      var key = keys[index];\n      this[key] = options[key];\n    }\n\n    if (this.start !== undefined) {\n      if ('number' !== typeof this.start) {\n        throw TypeError('start must be a Number');\n      }\n      if (this.start < 0) {\n        throw new Error('start must be >= zero');\n      }\n\n      this.pos = this.start;\n    }\n\n    this.busy = false;\n    this._queue = [];\n\n    if (this.fd === null) {\n      this._open = fs.open;\n      this._queue.push([this._open, this.path, this.flags, this.mode, undefined]);\n      this.flush();\n    }\n  }\n}\n\n\n//# sourceURL=./node_modules/graceful-fs/legacy-streams.js");

/***/ }),

/***/ "./node_modules/graceful-fs/polyfills.js":
/*!***********************************************!*\
  !*** ./node_modules/graceful-fs/polyfills.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var constants = __webpack_require__(/*! constants */ \"constants\")\n\nvar origCwd = process.cwd\nvar cwd = null\n\nvar platform = process.env.GRACEFUL_FS_PLATFORM || process.platform\n\nprocess.cwd = function() {\n  if (!cwd)\n    cwd = origCwd.call(process)\n  return cwd\n}\ntry {\n  process.cwd()\n} catch (er) {}\n\nvar chdir = process.chdir\nprocess.chdir = function(d) {\n  cwd = null\n  chdir.call(process, d)\n}\n\nmodule.exports = patch\n\nfunction patch (fs) {\n  // (re-)implement some things that are known busted or missing.\n\n  // lchmod, broken prior to 0.6.2\n  // back-port the fix here.\n  if (constants.hasOwnProperty('O_SYMLINK') &&\n      process.version.match(/^v0\\.6\\.[0-2]|^v0\\.5\\./)) {\n    patchLchmod(fs)\n  }\n\n  // lutimes implementation, or no-op\n  if (!fs.lutimes) {\n    patchLutimes(fs)\n  }\n\n  // https://github.com/isaacs/node-graceful-fs/issues/4\n  // Chown should not fail on einval or eperm if non-root.\n  // It should not fail on enosys ever, as this just indicates\n  // that a fs doesn't support the intended operation.\n\n  fs.chown = chownFix(fs.chown)\n  fs.fchown = chownFix(fs.fchown)\n  fs.lchown = chownFix(fs.lchown)\n\n  fs.chmod = chmodFix(fs.chmod)\n  fs.fchmod = chmodFix(fs.fchmod)\n  fs.lchmod = chmodFix(fs.lchmod)\n\n  fs.chownSync = chownFixSync(fs.chownSync)\n  fs.fchownSync = chownFixSync(fs.fchownSync)\n  fs.lchownSync = chownFixSync(fs.lchownSync)\n\n  fs.chmodSync = chmodFixSync(fs.chmodSync)\n  fs.fchmodSync = chmodFixSync(fs.fchmodSync)\n  fs.lchmodSync = chmodFixSync(fs.lchmodSync)\n\n  fs.stat = statFix(fs.stat)\n  fs.fstat = statFix(fs.fstat)\n  fs.lstat = statFix(fs.lstat)\n\n  fs.statSync = statFixSync(fs.statSync)\n  fs.fstatSync = statFixSync(fs.fstatSync)\n  fs.lstatSync = statFixSync(fs.lstatSync)\n\n  // if lchmod/lchown do not exist, then make them no-ops\n  if (!fs.lchmod) {\n    fs.lchmod = function (path, mode, cb) {\n      if (cb) process.nextTick(cb)\n    }\n    fs.lchmodSync = function () {}\n  }\n  if (!fs.lchown) {\n    fs.lchown = function (path, uid, gid, cb) {\n      if (cb) process.nextTick(cb)\n    }\n    fs.lchownSync = function () {}\n  }\n\n  // on Windows, A/V software can lock the directory, causing this\n  // to fail with an EACCES or EPERM if the directory contains newly\n  // created files.  Try again on failure, for up to 60 seconds.\n\n  // Set the timeout this long because some Windows Anti-Virus, such as Parity\n  // bit9, may lock files for up to a minute, causing npm package install\n  // failures. Also, take care to yield the scheduler. Windows scheduling gives\n  // CPU to a busy looping process, which can cause the program causing the lock\n  // contention to be starved of CPU by node, so the contention doesn't resolve.\n  if (platform === \"win32\") {\n    fs.rename = (function (fs$rename) { return function (from, to, cb) {\n      var start = Date.now()\n      var backoff = 0;\n      fs$rename(from, to, function CB (er) {\n        if (er\n            && (er.code === \"EACCES\" || er.code === \"EPERM\")\n            && Date.now() - start < 60000) {\n          setTimeout(function() {\n            fs.stat(to, function (stater, st) {\n              if (stater && stater.code === \"ENOENT\")\n                fs$rename(from, to, CB);\n              else\n                cb(er)\n            })\n          }, backoff)\n          if (backoff < 100)\n            backoff += 10;\n          return;\n        }\n        if (cb) cb(er)\n      })\n    }})(fs.rename)\n  }\n\n  // if read() returns EAGAIN, then just try it again.\n  fs.read = (function (fs$read) {\n    function read (fd, buffer, offset, length, position, callback_) {\n      var callback\n      if (callback_ && typeof callback_ === 'function') {\n        var eagCounter = 0\n        callback = function (er, _, __) {\n          if (er && er.code === 'EAGAIN' && eagCounter < 10) {\n            eagCounter ++\n            return fs$read.call(fs, fd, buffer, offset, length, position, callback)\n          }\n          callback_.apply(this, arguments)\n        }\n      }\n      return fs$read.call(fs, fd, buffer, offset, length, position, callback)\n    }\n\n    // This ensures `util.promisify` works as it does for native `fs.read`.\n    read.__proto__ = fs$read\n    return read\n  })(fs.read)\n\n  fs.readSync = (function (fs$readSync) { return function (fd, buffer, offset, length, position) {\n    var eagCounter = 0\n    while (true) {\n      try {\n        return fs$readSync.call(fs, fd, buffer, offset, length, position)\n      } catch (er) {\n        if (er.code === 'EAGAIN' && eagCounter < 10) {\n          eagCounter ++\n          continue\n        }\n        throw er\n      }\n    }\n  }})(fs.readSync)\n\n  function patchLchmod (fs) {\n    fs.lchmod = function (path, mode, callback) {\n      fs.open( path\n             , constants.O_WRONLY | constants.O_SYMLINK\n             , mode\n             , function (err, fd) {\n        if (err) {\n          if (callback) callback(err)\n          return\n        }\n        // prefer to return the chmod error, if one occurs,\n        // but still try to close, and report closing errors if they occur.\n        fs.fchmod(fd, mode, function (err) {\n          fs.close(fd, function(err2) {\n            if (callback) callback(err || err2)\n          })\n        })\n      })\n    }\n\n    fs.lchmodSync = function (path, mode) {\n      var fd = fs.openSync(path, constants.O_WRONLY | constants.O_SYMLINK, mode)\n\n      // prefer to return the chmod error, if one occurs,\n      // but still try to close, and report closing errors if they occur.\n      var threw = true\n      var ret\n      try {\n        ret = fs.fchmodSync(fd, mode)\n        threw = false\n      } finally {\n        if (threw) {\n          try {\n            fs.closeSync(fd)\n          } catch (er) {}\n        } else {\n          fs.closeSync(fd)\n        }\n      }\n      return ret\n    }\n  }\n\n  function patchLutimes (fs) {\n    if (constants.hasOwnProperty(\"O_SYMLINK\")) {\n      fs.lutimes = function (path, at, mt, cb) {\n        fs.open(path, constants.O_SYMLINK, function (er, fd) {\n          if (er) {\n            if (cb) cb(er)\n            return\n          }\n          fs.futimes(fd, at, mt, function (er) {\n            fs.close(fd, function (er2) {\n              if (cb) cb(er || er2)\n            })\n          })\n        })\n      }\n\n      fs.lutimesSync = function (path, at, mt) {\n        var fd = fs.openSync(path, constants.O_SYMLINK)\n        var ret\n        var threw = true\n        try {\n          ret = fs.futimesSync(fd, at, mt)\n          threw = false\n        } finally {\n          if (threw) {\n            try {\n              fs.closeSync(fd)\n            } catch (er) {}\n          } else {\n            fs.closeSync(fd)\n          }\n        }\n        return ret\n      }\n\n    } else {\n      fs.lutimes = function (_a, _b, _c, cb) { if (cb) process.nextTick(cb) }\n      fs.lutimesSync = function () {}\n    }\n  }\n\n  function chmodFix (orig) {\n    if (!orig) return orig\n    return function (target, mode, cb) {\n      return orig.call(fs, target, mode, function (er) {\n        if (chownErOk(er)) er = null\n        if (cb) cb.apply(this, arguments)\n      })\n    }\n  }\n\n  function chmodFixSync (orig) {\n    if (!orig) return orig\n    return function (target, mode) {\n      try {\n        return orig.call(fs, target, mode)\n      } catch (er) {\n        if (!chownErOk(er)) throw er\n      }\n    }\n  }\n\n\n  function chownFix (orig) {\n    if (!orig) return orig\n    return function (target, uid, gid, cb) {\n      return orig.call(fs, target, uid, gid, function (er) {\n        if (chownErOk(er)) er = null\n        if (cb) cb.apply(this, arguments)\n      })\n    }\n  }\n\n  function chownFixSync (orig) {\n    if (!orig) return orig\n    return function (target, uid, gid) {\n      try {\n        return orig.call(fs, target, uid, gid)\n      } catch (er) {\n        if (!chownErOk(er)) throw er\n      }\n    }\n  }\n\n  function statFix (orig) {\n    if (!orig) return orig\n    // Older versions of Node erroneously returned signed integers for\n    // uid + gid.\n    return function (target, options, cb) {\n      if (typeof options === 'function') {\n        cb = options\n        options = null\n      }\n      function callback (er, stats) {\n        if (stats) {\n          if (stats.uid < 0) stats.uid += 0x100000000\n          if (stats.gid < 0) stats.gid += 0x100000000\n        }\n        if (cb) cb.apply(this, arguments)\n      }\n      return options ? orig.call(fs, target, options, callback)\n        : orig.call(fs, target, callback)\n    }\n  }\n\n  function statFixSync (orig) {\n    if (!orig) return orig\n    // Older versions of Node erroneously returned signed integers for\n    // uid + gid.\n    return function (target, options) {\n      var stats = options ? orig.call(fs, target, options)\n        : orig.call(fs, target)\n      if (stats.uid < 0) stats.uid += 0x100000000\n      if (stats.gid < 0) stats.gid += 0x100000000\n      return stats;\n    }\n  }\n\n  // ENOSYS means that the fs doesn't support the op. Just ignore\n  // that, because it doesn't matter.\n  //\n  // if there's no getuid, or if getuid() is something other\n  // than 0, and the error is EINVAL or EPERM, then just ignore\n  // it.\n  //\n  // This specific case is a silent failure in cp, install, tar,\n  // and most other unix tools that manage permissions.\n  //\n  // When running as root, or if other types of errors are\n  // encountered, then it's strict.\n  function chownErOk (er) {\n    if (!er)\n      return true\n\n    if (er.code === \"ENOSYS\")\n      return true\n\n    var nonroot = !process.getuid || process.getuid() !== 0\n    if (nonroot) {\n      if (er.code === \"EINVAL\" || er.code === \"EPERM\")\n        return true\n    }\n\n    return false\n  }\n}\n\n\n//# sourceURL=./node_modules/graceful-fs/polyfills.js");

/***/ }),

/***/ "./node_modules/is-stream/index.js":
/*!*****************************************!*\
  !*** ./node_modules/is-stream/index.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar isStream = module.exports = function (stream) {\n\treturn stream !== null && typeof stream === 'object' && typeof stream.pipe === 'function';\n};\n\nisStream.writable = function (stream) {\n\treturn isStream(stream) && stream.writable !== false && typeof stream._write === 'function' && typeof stream._writableState === 'object';\n};\n\nisStream.readable = function (stream) {\n\treturn isStream(stream) && stream.readable !== false && typeof stream._read === 'function' && typeof stream._readableState === 'object';\n};\n\nisStream.duplex = function (stream) {\n\treturn isStream.writable(stream) && isStream.readable(stream);\n};\n\nisStream.transform = function (stream) {\n\treturn isStream.duplex(stream) && typeof stream._transform === 'function' && typeof stream._transformState === 'object';\n};\n\n\n//# sourceURL=./node_modules/is-stream/index.js");

/***/ }),

/***/ "./node_modules/isomorphic-fetch/fetch-npm-node.js":
/*!*********************************************************!*\
  !*** ./node_modules/isomorphic-fetch/fetch-npm-node.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar realFetch = __webpack_require__(/*! node-fetch */ \"./node_modules/node-fetch/index.js\");\nmodule.exports = function(url, options) {\n\tif (/^\\/\\//.test(url)) {\n\t\turl = 'https:' + url;\n\t}\n\treturn realFetch.call(this, url, options);\n};\n\nif (!global.fetch) {\n\tglobal.fetch = module.exports;\n\tglobal.Response = realFetch.Response;\n\tglobal.Headers = realFetch.Headers;\n\tglobal.Request = realFetch.Request;\n}\n\n\n//# sourceURL=./node_modules/isomorphic-fetch/fetch-npm-node.js");

/***/ }),

/***/ "./node_modules/jsonfile/index.js":
/*!****************************************!*\
  !*** ./node_modules/jsonfile/index.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var _fs\ntry {\n  _fs = __webpack_require__(/*! graceful-fs */ \"./node_modules/graceful-fs/graceful-fs.js\")\n} catch (_) {\n  _fs = __webpack_require__(/*! fs */ \"fs\")\n}\n\nfunction readFile (file, options, callback) {\n  if (callback == null) {\n    callback = options\n    options = {}\n  }\n\n  if (typeof options === 'string') {\n    options = {encoding: options}\n  }\n\n  options = options || {}\n  var fs = options.fs || _fs\n\n  var shouldThrow = true\n  if ('throws' in options) {\n    shouldThrow = options.throws\n  }\n\n  fs.readFile(file, options, function (err, data) {\n    if (err) return callback(err)\n\n    data = stripBom(data)\n\n    var obj\n    try {\n      obj = JSON.parse(data, options ? options.reviver : null)\n    } catch (err2) {\n      if (shouldThrow) {\n        err2.message = file + ': ' + err2.message\n        return callback(err2)\n      } else {\n        return callback(null, null)\n      }\n    }\n\n    callback(null, obj)\n  })\n}\n\nfunction readFileSync (file, options) {\n  options = options || {}\n  if (typeof options === 'string') {\n    options = {encoding: options}\n  }\n\n  var fs = options.fs || _fs\n\n  var shouldThrow = true\n  if ('throws' in options) {\n    shouldThrow = options.throws\n  }\n\n  try {\n    var content = fs.readFileSync(file, options)\n    content = stripBom(content)\n    return JSON.parse(content, options.reviver)\n  } catch (err) {\n    if (shouldThrow) {\n      err.message = file + ': ' + err.message\n      throw err\n    } else {\n      return null\n    }\n  }\n}\n\nfunction stringify (obj, options) {\n  var spaces\n  var EOL = '\\n'\n  if (typeof options === 'object' && options !== null) {\n    if (options.spaces) {\n      spaces = options.spaces\n    }\n    if (options.EOL) {\n      EOL = options.EOL\n    }\n  }\n\n  var str = JSON.stringify(obj, options ? options.replacer : null, spaces)\n\n  return str.replace(/\\n/g, EOL) + EOL\n}\n\nfunction writeFile (file, obj, options, callback) {\n  if (callback == null) {\n    callback = options\n    options = {}\n  }\n  options = options || {}\n  var fs = options.fs || _fs\n\n  var str = ''\n  try {\n    str = stringify(obj, options)\n  } catch (err) {\n    // Need to return whether a callback was passed or not\n    if (callback) callback(err, null)\n    return\n  }\n\n  fs.writeFile(file, str, options, callback)\n}\n\nfunction writeFileSync (file, obj, options) {\n  options = options || {}\n  var fs = options.fs || _fs\n\n  var str = stringify(obj, options)\n  // not sure if fs.writeFileSync returns anything, but just in case\n  return fs.writeFileSync(file, str, options)\n}\n\nfunction stripBom (content) {\n  // we do this because JSON.parse would convert it to a utf8 string if encoding wasn't specified\n  if (Buffer.isBuffer(content)) content = content.toString('utf8')\n  content = content.replace(/^\\uFEFF/, '')\n  return content\n}\n\nvar jsonfile = {\n  readFile: readFile,\n  readFileSync: readFileSync,\n  writeFile: writeFile,\n  writeFileSync: writeFileSync\n}\n\nmodule.exports = jsonfile\n\n\n//# sourceURL=./node_modules/jsonfile/index.js");

/***/ }),

/***/ "./node_modules/node-fetch/index.js":
/*!******************************************!*\
  !*** ./node_modules/node-fetch/index.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("\n/**\n * index.js\n *\n * a request API compatible with window.fetch\n */\n\nvar parse_url = __webpack_require__(/*! url */ \"url\").parse;\nvar resolve_url = __webpack_require__(/*! url */ \"url\").resolve;\nvar http = __webpack_require__(/*! http */ \"http\");\nvar https = __webpack_require__(/*! https */ \"https\");\nvar zlib = __webpack_require__(/*! zlib */ \"zlib\");\nvar stream = __webpack_require__(/*! stream */ \"stream\");\n\nvar Body = __webpack_require__(/*! ./lib/body */ \"./node_modules/node-fetch/lib/body.js\");\nvar Response = __webpack_require__(/*! ./lib/response */ \"./node_modules/node-fetch/lib/response.js\");\nvar Headers = __webpack_require__(/*! ./lib/headers */ \"./node_modules/node-fetch/lib/headers.js\");\nvar Request = __webpack_require__(/*! ./lib/request */ \"./node_modules/node-fetch/lib/request.js\");\nvar FetchError = __webpack_require__(/*! ./lib/fetch-error */ \"./node_modules/node-fetch/lib/fetch-error.js\");\n\n// commonjs\nmodule.exports = Fetch;\n// es6 default export compatibility\nmodule.exports.default = module.exports;\n\n/**\n * Fetch class\n *\n * @param   Mixed    url   Absolute url or Request instance\n * @param   Object   opts  Fetch options\n * @return  Promise\n */\nfunction Fetch(url, opts) {\n\n\t// allow call as function\n\tif (!(this instanceof Fetch))\n\t\treturn new Fetch(url, opts);\n\n\t// allow custom promise\n\tif (!Fetch.Promise) {\n\t\tthrow new Error('native promise missing, set Fetch.Promise to your favorite alternative');\n\t}\n\n\tBody.Promise = Fetch.Promise;\n\n\tvar self = this;\n\n\t// wrap http.request into fetch\n\treturn new Fetch.Promise(function(resolve, reject) {\n\t\t// build request object\n\t\tvar options = new Request(url, opts);\n\n\t\tif (!options.protocol || !options.hostname) {\n\t\t\tthrow new Error('only absolute urls are supported');\n\t\t}\n\n\t\tif (options.protocol !== 'http:' && options.protocol !== 'https:') {\n\t\t\tthrow new Error('only http(s) protocols are supported');\n\t\t}\n\n\t\tvar send;\n\t\tif (options.protocol === 'https:') {\n\t\t\tsend = https.request;\n\t\t} else {\n\t\t\tsend = http.request;\n\t\t}\n\n\t\t// normalize headers\n\t\tvar headers = new Headers(options.headers);\n\n\t\tif (options.compress) {\n\t\t\theaders.set('accept-encoding', 'gzip,deflate');\n\t\t}\n\n\t\tif (!headers.has('user-agent')) {\n\t\t\theaders.set('user-agent', 'node-fetch/1.0 (+https://github.com/bitinn/node-fetch)');\n\t\t}\n\n\t\tif (!headers.has('connection') && !options.agent) {\n\t\t\theaders.set('connection', 'close');\n\t\t}\n\n\t\tif (!headers.has('accept')) {\n\t\t\theaders.set('accept', '*/*');\n\t\t}\n\n\t\t// detect form data input from form-data module, this hack avoid the need to pass multipart header manually\n\t\tif (!headers.has('content-type') && options.body && typeof options.body.getBoundary === 'function') {\n\t\t\theaders.set('content-type', 'multipart/form-data; boundary=' + options.body.getBoundary());\n\t\t}\n\n\t\t// bring node-fetch closer to browser behavior by setting content-length automatically\n\t\tif (!headers.has('content-length') && /post|put|patch|delete/i.test(options.method)) {\n\t\t\tif (typeof options.body === 'string') {\n\t\t\t\theaders.set('content-length', Buffer.byteLength(options.body));\n\t\t\t// detect form data input from form-data module, this hack avoid the need to add content-length header manually\n\t\t\t} else if (options.body && typeof options.body.getLengthSync === 'function') {\n\t\t\t\t// for form-data 1.x\n\t\t\t\tif (options.body._lengthRetrievers && options.body._lengthRetrievers.length == 0) {\n\t\t\t\t\theaders.set('content-length', options.body.getLengthSync().toString());\n\t\t\t\t// for form-data 2.x\n\t\t\t\t} else if (options.body.hasKnownLength && options.body.hasKnownLength()) {\n\t\t\t\t\theaders.set('content-length', options.body.getLengthSync().toString());\n\t\t\t\t}\n\t\t\t// this is only necessary for older nodejs releases (before iojs merge)\n\t\t\t} else if (options.body === undefined || options.body === null) {\n\t\t\t\theaders.set('content-length', '0');\n\t\t\t}\n\t\t}\n\n\t\toptions.headers = headers.raw();\n\n\t\t// http.request only support string as host header, this hack make custom host header possible\n\t\tif (options.headers.host) {\n\t\t\toptions.headers.host = options.headers.host[0];\n\t\t}\n\n\t\t// send request\n\t\tvar req = send(options);\n\t\tvar reqTimeout;\n\n\t\tif (options.timeout) {\n\t\t\treq.once('socket', function(socket) {\n\t\t\t\treqTimeout = setTimeout(function() {\n\t\t\t\t\treq.abort();\n\t\t\t\t\treject(new FetchError('network timeout at: ' + options.url, 'request-timeout'));\n\t\t\t\t}, options.timeout);\n\t\t\t});\n\t\t}\n\n\t\treq.on('error', function(err) {\n\t\t\tclearTimeout(reqTimeout);\n\t\t\treject(new FetchError('request to ' + options.url + ' failed, reason: ' + err.message, 'system', err));\n\t\t});\n\n\t\treq.on('response', function(res) {\n\t\t\tclearTimeout(reqTimeout);\n\n\t\t\t// handle redirect\n\t\t\tif (self.isRedirect(res.statusCode) && options.redirect !== 'manual') {\n\t\t\t\tif (options.redirect === 'error') {\n\t\t\t\t\treject(new FetchError('redirect mode is set to error: ' + options.url, 'no-redirect'));\n\t\t\t\t\treturn;\n\t\t\t\t}\n\n\t\t\t\tif (options.counter >= options.follow) {\n\t\t\t\t\treject(new FetchError('maximum redirect reached at: ' + options.url, 'max-redirect'));\n\t\t\t\t\treturn;\n\t\t\t\t}\n\n\t\t\t\tif (!res.headers.location) {\n\t\t\t\t\treject(new FetchError('redirect location header missing at: ' + options.url, 'invalid-redirect'));\n\t\t\t\t\treturn;\n\t\t\t\t}\n\n\t\t\t\t// per fetch spec, for POST request with 301/302 response, or any request with 303 response, use GET when following redirect\n\t\t\t\tif (res.statusCode === 303\n\t\t\t\t\t|| ((res.statusCode === 301 || res.statusCode === 302) && options.method === 'POST'))\n\t\t\t\t{\n\t\t\t\t\toptions.method = 'GET';\n\t\t\t\t\tdelete options.body;\n\t\t\t\t\tdelete options.headers['content-length'];\n\t\t\t\t}\n\n\t\t\t\toptions.counter++;\n\n\t\t\t\tresolve(Fetch(resolve_url(options.url, res.headers.location), options));\n\t\t\t\treturn;\n\t\t\t}\n\n\t\t\t// normalize location header for manual redirect mode\n\t\t\tvar headers = new Headers(res.headers);\n\t\t\tif (options.redirect === 'manual' && headers.has('location')) {\n\t\t\t\theaders.set('location', resolve_url(options.url, headers.get('location')));\n\t\t\t}\n\n\t\t\t// prepare response\n\t\t\tvar body = res.pipe(new stream.PassThrough());\n\t\t\tvar response_options = {\n\t\t\t\turl: options.url\n\t\t\t\t, status: res.statusCode\n\t\t\t\t, statusText: res.statusMessage\n\t\t\t\t, headers: headers\n\t\t\t\t, size: options.size\n\t\t\t\t, timeout: options.timeout\n\t\t\t};\n\n\t\t\t// response object\n\t\t\tvar output;\n\n\t\t\t// in following scenarios we ignore compression support\n\t\t\t// 1. compression support is disabled\n\t\t\t// 2. HEAD request\n\t\t\t// 3. no content-encoding header\n\t\t\t// 4. no content response (204)\n\t\t\t// 5. content not modified response (304)\n\t\t\tif (!options.compress || options.method === 'HEAD' || !headers.has('content-encoding') || res.statusCode === 204 || res.statusCode === 304) {\n\t\t\t\toutput = new Response(body, response_options);\n\t\t\t\tresolve(output);\n\t\t\t\treturn;\n\t\t\t}\n\n\t\t\t// otherwise, check for gzip or deflate\n\t\t\tvar name = headers.get('content-encoding');\n\n\t\t\t// for gzip\n\t\t\tif (name == 'gzip' || name == 'x-gzip') {\n\t\t\t\tbody = body.pipe(zlib.createGunzip());\n\t\t\t\toutput = new Response(body, response_options);\n\t\t\t\tresolve(output);\n\t\t\t\treturn;\n\n\t\t\t// for deflate\n\t\t\t} else if (name == 'deflate' || name == 'x-deflate') {\n\t\t\t\t// handle the infamous raw deflate response from old servers\n\t\t\t\t// a hack for old IIS and Apache servers\n\t\t\t\tvar raw = res.pipe(new stream.PassThrough());\n\t\t\t\traw.once('data', function(chunk) {\n\t\t\t\t\t// see http://stackoverflow.com/questions/37519828\n\t\t\t\t\tif ((chunk[0] & 0x0F) === 0x08) {\n\t\t\t\t\t\tbody = body.pipe(zlib.createInflate());\n\t\t\t\t\t} else {\n\t\t\t\t\t\tbody = body.pipe(zlib.createInflateRaw());\n\t\t\t\t\t}\n\t\t\t\t\toutput = new Response(body, response_options);\n\t\t\t\t\tresolve(output);\n\t\t\t\t});\n\t\t\t\treturn;\n\t\t\t}\n\n\t\t\t// otherwise, use response as-is\n\t\t\toutput = new Response(body, response_options);\n\t\t\tresolve(output);\n\t\t\treturn;\n\t\t});\n\n\t\t// accept string, buffer or readable stream as body\n\t\t// per spec we will call tostring on non-stream objects\n\t\tif (typeof options.body === 'string') {\n\t\t\treq.write(options.body);\n\t\t\treq.end();\n\t\t} else if (options.body instanceof Buffer) {\n\t\t\treq.write(options.body);\n\t\t\treq.end();\n\t\t} else if (typeof options.body === 'object' && options.body.pipe) {\n\t\t\toptions.body.pipe(req);\n\t\t} else if (typeof options.body === 'object') {\n\t\t\treq.write(options.body.toString());\n\t\t\treq.end();\n\t\t} else {\n\t\t\treq.end();\n\t\t}\n\t});\n\n};\n\n/**\n * Redirect code matching\n *\n * @param   Number   code  Status code\n * @return  Boolean\n */\nFetch.prototype.isRedirect = function(code) {\n\treturn code === 301 || code === 302 || code === 303 || code === 307 || code === 308;\n}\n\n// expose Promise\nFetch.Promise = global.Promise;\nFetch.Response = Response;\nFetch.Headers = Headers;\nFetch.Request = Request;\n\n\n//# sourceURL=./node_modules/node-fetch/index.js");

/***/ }),

/***/ "./node_modules/node-fetch/lib/body.js":
/*!*********************************************!*\
  !*** ./node_modules/node-fetch/lib/body.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("\n/**\n * body.js\n *\n * Body interface provides common methods for Request and Response\n */\n\nvar convert = __webpack_require__(/*! encoding */ \"./node_modules/encoding/lib/encoding.js\").convert;\nvar bodyStream = __webpack_require__(/*! is-stream */ \"./node_modules/is-stream/index.js\");\nvar PassThrough = __webpack_require__(/*! stream */ \"stream\").PassThrough;\nvar FetchError = __webpack_require__(/*! ./fetch-error */ \"./node_modules/node-fetch/lib/fetch-error.js\");\n\nmodule.exports = Body;\n\n/**\n * Body class\n *\n * @param   Stream  body  Readable stream\n * @param   Object  opts  Response options\n * @return  Void\n */\nfunction Body(body, opts) {\n\n\topts = opts || {};\n\n\tthis.body = body;\n\tthis.bodyUsed = false;\n\tthis.size = opts.size || 0;\n\tthis.timeout = opts.timeout || 0;\n\tthis._raw = [];\n\tthis._abort = false;\n\n}\n\n/**\n * Decode response as json\n *\n * @return  Promise\n */\nBody.prototype.json = function() {\n\n\tvar self = this;\n\n\treturn this._decode().then(function(buffer) {\n\t\ttry {\n\t\t\treturn JSON.parse(buffer.toString());\n\t\t} catch (err) {\n\t\t\treturn Body.Promise.reject(new FetchError('invalid json response body at ' + self.url + ' reason: ' + err.message, 'invalid-json'));\n\t\t}\n\t});\n\n};\n\n/**\n * Decode response as text\n *\n * @return  Promise\n */\nBody.prototype.text = function() {\n\n\treturn this._decode().then(function(buffer) {\n\t\treturn buffer.toString();\n\t});\n\n};\n\n/**\n * Decode response as buffer (non-spec api)\n *\n * @return  Promise\n */\nBody.prototype.buffer = function() {\n\n\treturn this._decode();\n\n};\n\n/**\n * Decode buffers into utf-8 string\n *\n * @return  Promise\n */\nBody.prototype._decode = function() {\n\n\tvar self = this;\n\n\tif (this.bodyUsed) {\n\t\treturn Body.Promise.reject(new Error('body used already for: ' + this.url));\n\t}\n\n\tthis.bodyUsed = true;\n\tthis._bytes = 0;\n\tthis._abort = false;\n\tthis._raw = [];\n\n\treturn new Body.Promise(function(resolve, reject) {\n\t\tvar resTimeout;\n\n\t\t// body is string\n\t\tif (typeof self.body === 'string') {\n\t\t\tself._bytes = self.body.length;\n\t\t\tself._raw = [new Buffer(self.body)];\n\t\t\treturn resolve(self._convert());\n\t\t}\n\n\t\t// body is buffer\n\t\tif (self.body instanceof Buffer) {\n\t\t\tself._bytes = self.body.length;\n\t\t\tself._raw = [self.body];\n\t\t\treturn resolve(self._convert());\n\t\t}\n\n\t\t// allow timeout on slow response body\n\t\tif (self.timeout) {\n\t\t\tresTimeout = setTimeout(function() {\n\t\t\t\tself._abort = true;\n\t\t\t\treject(new FetchError('response timeout at ' + self.url + ' over limit: ' + self.timeout, 'body-timeout'));\n\t\t\t}, self.timeout);\n\t\t}\n\n\t\t// handle stream error, such as incorrect content-encoding\n\t\tself.body.on('error', function(err) {\n\t\t\treject(new FetchError('invalid response body at: ' + self.url + ' reason: ' + err.message, 'system', err));\n\t\t});\n\n\t\t// body is stream\n\t\tself.body.on('data', function(chunk) {\n\t\t\tif (self._abort || chunk === null) {\n\t\t\t\treturn;\n\t\t\t}\n\n\t\t\tif (self.size && self._bytes + chunk.length > self.size) {\n\t\t\t\tself._abort = true;\n\t\t\t\treject(new FetchError('content size at ' + self.url + ' over limit: ' + self.size, 'max-size'));\n\t\t\t\treturn;\n\t\t\t}\n\n\t\t\tself._bytes += chunk.length;\n\t\t\tself._raw.push(chunk);\n\t\t});\n\n\t\tself.body.on('end', function() {\n\t\t\tif (self._abort) {\n\t\t\t\treturn;\n\t\t\t}\n\n\t\t\tclearTimeout(resTimeout);\n\t\t\tresolve(self._convert());\n\t\t});\n\t});\n\n};\n\n/**\n * Detect buffer encoding and convert to target encoding\n * ref: http://www.w3.org/TR/2011/WD-html5-20110113/parsing.html#determining-the-character-encoding\n *\n * @param   String  encoding  Target encoding\n * @return  String\n */\nBody.prototype._convert = function(encoding) {\n\n\tencoding = encoding || 'utf-8';\n\n\tvar ct = this.headers.get('content-type');\n\tvar charset = 'utf-8';\n\tvar res, str;\n\n\t// header\n\tif (ct) {\n\t\t// skip encoding detection altogether if not html/xml/plain text\n\t\tif (!/text\\/html|text\\/plain|\\+xml|\\/xml/i.test(ct)) {\n\t\t\treturn Buffer.concat(this._raw);\n\t\t}\n\n\t\tres = /charset=([^;]*)/i.exec(ct);\n\t}\n\n\t// no charset in content type, peek at response body for at most 1024 bytes\n\tif (!res && this._raw.length > 0) {\n\t\tfor (var i = 0; i < this._raw.length; i++) {\n\t\t\tstr += this._raw[i].toString()\n\t\t\tif (str.length > 1024) {\n\t\t\t\tbreak;\n\t\t\t}\n\t\t}\n\t\tstr = str.substr(0, 1024);\n\t}\n\n\t// html5\n\tif (!res && str) {\n\t\tres = /<meta.+?charset=(['\"])(.+?)\\1/i.exec(str);\n\t}\n\n\t// html4\n\tif (!res && str) {\n\t\tres = /<meta[\\s]+?http-equiv=(['\"])content-type\\1[\\s]+?content=(['\"])(.+?)\\2/i.exec(str);\n\n\t\tif (res) {\n\t\t\tres = /charset=(.*)/i.exec(res.pop());\n\t\t}\n\t}\n\n\t// xml\n\tif (!res && str) {\n\t\tres = /<\\?xml.+?encoding=(['\"])(.+?)\\1/i.exec(str);\n\t}\n\n\t// found charset\n\tif (res) {\n\t\tcharset = res.pop();\n\n\t\t// prevent decode issues when sites use incorrect encoding\n\t\t// ref: https://hsivonen.fi/encoding-menu/\n\t\tif (charset === 'gb2312' || charset === 'gbk') {\n\t\t\tcharset = 'gb18030';\n\t\t}\n\t}\n\n\t// turn raw buffers into a single utf-8 buffer\n\treturn convert(\n\t\tBuffer.concat(this._raw)\n\t\t, encoding\n\t\t, charset\n\t);\n\n};\n\n/**\n * Clone body given Res/Req instance\n *\n * @param   Mixed  instance  Response or Request instance\n * @return  Mixed\n */\nBody.prototype._clone = function(instance) {\n\tvar p1, p2;\n\tvar body = instance.body;\n\n\t// don't allow cloning a used body\n\tif (instance.bodyUsed) {\n\t\tthrow new Error('cannot clone body after it is used');\n\t}\n\n\t// check that body is a stream and not form-data object\n\t// note: we can't clone the form-data object without having it as a dependency\n\tif (bodyStream(body) && typeof body.getBoundary !== 'function') {\n\t\t// tee instance body\n\t\tp1 = new PassThrough();\n\t\tp2 = new PassThrough();\n\t\tbody.pipe(p1);\n\t\tbody.pipe(p2);\n\t\t// set instance body to teed body and return the other teed body\n\t\tinstance.body = p1;\n\t\tbody = p2;\n\t}\n\n\treturn body;\n}\n\n// expose Promise\nBody.Promise = global.Promise;\n\n\n//# sourceURL=./node_modules/node-fetch/lib/body.js");

/***/ }),

/***/ "./node_modules/node-fetch/lib/fetch-error.js":
/*!****************************************************!*\
  !*** ./node_modules/node-fetch/lib/fetch-error.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("\n/**\n * fetch-error.js\n *\n * FetchError interface for operational errors\n */\n\nmodule.exports = FetchError;\n\n/**\n * Create FetchError instance\n *\n * @param   String      message      Error message for human\n * @param   String      type         Error type for machine\n * @param   String      systemError  For Node.js system error\n * @return  FetchError\n */\nfunction FetchError(message, type, systemError) {\n\n\tthis.name = this.constructor.name;\n\tthis.message = message;\n\tthis.type = type;\n\n\t// when err.type is `system`, err.code contains system error code\n\tif (systemError) {\n\t\tthis.code = this.errno = systemError.code;\n\t}\n\n\t// hide custom error implementation details from end-users\n\tError.captureStackTrace(this, this.constructor);\n}\n\n__webpack_require__(/*! util */ \"util\").inherits(FetchError, Error);\n\n\n//# sourceURL=./node_modules/node-fetch/lib/fetch-error.js");

/***/ }),

/***/ "./node_modules/node-fetch/lib/headers.js":
/*!************************************************!*\
  !*** ./node_modules/node-fetch/lib/headers.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("\n/**\n * headers.js\n *\n * Headers class offers convenient helpers\n */\n\nmodule.exports = Headers;\n\n/**\n * Headers class\n *\n * @param   Object  headers  Response headers\n * @return  Void\n */\nfunction Headers(headers) {\n\n\tvar self = this;\n\tthis._headers = {};\n\n\t// Headers\n\tif (headers instanceof Headers) {\n\t\theaders = headers.raw();\n\t}\n\n\t// plain object\n\tfor (var prop in headers) {\n\t\tif (!headers.hasOwnProperty(prop)) {\n\t\t\tcontinue;\n\t\t}\n\n\t\tif (typeof headers[prop] === 'string') {\n\t\t\tthis.set(prop, headers[prop]);\n\n\t\t} else if (typeof headers[prop] === 'number' && !isNaN(headers[prop])) {\n\t\t\tthis.set(prop, headers[prop].toString());\n\n\t\t} else if (Array.isArray(headers[prop])) {\n\t\t\theaders[prop].forEach(function(item) {\n\t\t\t\tself.append(prop, item.toString());\n\t\t\t});\n\t\t}\n\t}\n\n}\n\n/**\n * Return first header value given name\n *\n * @param   String  name  Header name\n * @return  Mixed\n */\nHeaders.prototype.get = function(name) {\n\tvar list = this._headers[name.toLowerCase()];\n\treturn list ? list[0] : null;\n};\n\n/**\n * Return all header values given name\n *\n * @param   String  name  Header name\n * @return  Array\n */\nHeaders.prototype.getAll = function(name) {\n\tif (!this.has(name)) {\n\t\treturn [];\n\t}\n\n\treturn this._headers[name.toLowerCase()];\n};\n\n/**\n * Iterate over all headers\n *\n * @param   Function  callback  Executed for each item with parameters (value, name, thisArg)\n * @param   Boolean   thisArg   `this` context for callback function\n * @return  Void\n */\nHeaders.prototype.forEach = function(callback, thisArg) {\n\tObject.getOwnPropertyNames(this._headers).forEach(function(name) {\n\t\tthis._headers[name].forEach(function(value) {\n\t\t\tcallback.call(thisArg, value, name, this)\n\t\t}, this)\n\t}, this)\n}\n\n/**\n * Overwrite header values given name\n *\n * @param   String  name   Header name\n * @param   String  value  Header value\n * @return  Void\n */\nHeaders.prototype.set = function(name, value) {\n\tthis._headers[name.toLowerCase()] = [value];\n};\n\n/**\n * Append a value onto existing header\n *\n * @param   String  name   Header name\n * @param   String  value  Header value\n * @return  Void\n */\nHeaders.prototype.append = function(name, value) {\n\tif (!this.has(name)) {\n\t\tthis.set(name, value);\n\t\treturn;\n\t}\n\n\tthis._headers[name.toLowerCase()].push(value);\n};\n\n/**\n * Check for header name existence\n *\n * @param   String   name  Header name\n * @return  Boolean\n */\nHeaders.prototype.has = function(name) {\n\treturn this._headers.hasOwnProperty(name.toLowerCase());\n};\n\n/**\n * Delete all header values given name\n *\n * @param   String  name  Header name\n * @return  Void\n */\nHeaders.prototype['delete'] = function(name) {\n\tdelete this._headers[name.toLowerCase()];\n};\n\n/**\n * Return raw headers (non-spec api)\n *\n * @return  Object\n */\nHeaders.prototype.raw = function() {\n\treturn this._headers;\n};\n\n\n//# sourceURL=./node_modules/node-fetch/lib/headers.js");

/***/ }),

/***/ "./node_modules/node-fetch/lib/request.js":
/*!************************************************!*\
  !*** ./node_modules/node-fetch/lib/request.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("\n/**\n * request.js\n *\n * Request class contains server only options\n */\n\nvar parse_url = __webpack_require__(/*! url */ \"url\").parse;\nvar Headers = __webpack_require__(/*! ./headers */ \"./node_modules/node-fetch/lib/headers.js\");\nvar Body = __webpack_require__(/*! ./body */ \"./node_modules/node-fetch/lib/body.js\");\n\nmodule.exports = Request;\n\n/**\n * Request class\n *\n * @param   Mixed   input  Url or Request instance\n * @param   Object  init   Custom options\n * @return  Void\n */\nfunction Request(input, init) {\n\tvar url, url_parsed;\n\n\t// normalize input\n\tif (!(input instanceof Request)) {\n\t\turl = input;\n\t\turl_parsed = parse_url(url);\n\t\tinput = {};\n\t} else {\n\t\turl = input.url;\n\t\turl_parsed = parse_url(url);\n\t}\n\n\t// normalize init\n\tinit = init || {};\n\n\t// fetch spec options\n\tthis.method = init.method || input.method || 'GET';\n\tthis.redirect = init.redirect || input.redirect || 'follow';\n\tthis.headers = new Headers(init.headers || input.headers || {});\n\tthis.url = url;\n\n\t// server only options\n\tthis.follow = init.follow !== undefined ?\n\t\tinit.follow : input.follow !== undefined ?\n\t\tinput.follow : 20;\n\tthis.compress = init.compress !== undefined ?\n\t\tinit.compress : input.compress !== undefined ?\n\t\tinput.compress : true;\n\tthis.counter = init.counter || input.counter || 0;\n\tthis.agent = init.agent || input.agent;\n\n\tBody.call(this, init.body || this._clone(input), {\n\t\ttimeout: init.timeout || input.timeout || 0,\n\t\tsize: init.size || input.size || 0\n\t});\n\n\t// server request options\n\tthis.protocol = url_parsed.protocol;\n\tthis.hostname = url_parsed.hostname;\n\tthis.port = url_parsed.port;\n\tthis.path = url_parsed.path;\n\tthis.auth = url_parsed.auth;\n}\n\nRequest.prototype = Object.create(Body.prototype);\n\n/**\n * Clone this request\n *\n * @return  Request\n */\nRequest.prototype.clone = function() {\n\treturn new Request(this);\n};\n\n\n//# sourceURL=./node_modules/node-fetch/lib/request.js");

/***/ }),

/***/ "./node_modules/node-fetch/lib/response.js":
/*!*************************************************!*\
  !*** ./node_modules/node-fetch/lib/response.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("\n/**\n * response.js\n *\n * Response class provides content decoding\n */\n\nvar http = __webpack_require__(/*! http */ \"http\");\nvar Headers = __webpack_require__(/*! ./headers */ \"./node_modules/node-fetch/lib/headers.js\");\nvar Body = __webpack_require__(/*! ./body */ \"./node_modules/node-fetch/lib/body.js\");\n\nmodule.exports = Response;\n\n/**\n * Response class\n *\n * @param   Stream  body  Readable stream\n * @param   Object  opts  Response options\n * @return  Void\n */\nfunction Response(body, opts) {\n\n\topts = opts || {};\n\n\tthis.url = opts.url;\n\tthis.status = opts.status || 200;\n\tthis.statusText = opts.statusText || http.STATUS_CODES[this.status];\n\tthis.headers = new Headers(opts.headers);\n\tthis.ok = this.status >= 200 && this.status < 300;\n\n\tBody.call(this, body, opts);\n\n}\n\nResponse.prototype = Object.create(Body.prototype);\n\n/**\n * Clone this response\n *\n * @return  Response\n */\nResponse.prototype.clone = function() {\n\treturn new Response(this._clone(this), {\n\t\turl: this.url\n\t\t, status: this.status\n\t\t, statusText: this.statusText\n\t\t, headers: this.headers\n\t\t, ok: this.ok\n\t});\n};\n\n\n//# sourceURL=./node_modules/node-fetch/lib/response.js");

/***/ }),

/***/ "./node_modules/universalify/index.js":
/*!********************************************!*\
  !*** ./node_modules/universalify/index.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nexports.fromCallback = function (fn) {\n  return Object.defineProperty(function () {\n    if (typeof arguments[arguments.length - 1] === 'function') fn.apply(this, arguments)\n    else {\n      return new Promise((resolve, reject) => {\n        arguments[arguments.length] = (err, res) => {\n          if (err) return reject(err)\n          resolve(res)\n        }\n        arguments.length++\n        fn.apply(this, arguments)\n      })\n    }\n  }, 'name', { value: fn.name })\n}\n\nexports.fromPromise = function (fn) {\n  return Object.defineProperty(function () {\n    const cb = arguments[arguments.length - 1]\n    if (typeof cb !== 'function') return fn.apply(this, arguments)\n    else fn.apply(this, arguments).then(r => cb(null, r), cb)\n  }, 'name', { value: fn.name })\n}\n\n\n//# sourceURL=./node_modules/universalify/index.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"assert\");\n\n//# sourceURL=external_%22assert%22");

/***/ }),

/***/ "constants":
/*!****************************!*\
  !*** external "constants" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"constants\");\n\n//# sourceURL=external_%22constants%22");

/***/ }),

/***/ "content-disposition":
/*!**************************************!*\
  !*** external "content-disposition" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"content-disposition\");\n\n//# sourceURL=external_%22content-disposition%22");

/***/ }),

/***/ "content-type":
/*!*******************************!*\
  !*** external "content-type" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"content-type\");\n\n//# sourceURL=external_%22content-type%22");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"fs\");\n\n//# sourceURL=external_%22fs%22");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"http\");\n\n//# sourceURL=external_%22http%22");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"https\");\n\n//# sourceURL=external_%22https%22");

/***/ }),

/***/ "iconv-lite":
/*!*****************************!*\
  !*** external "iconv-lite" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"iconv-lite\");\n\n//# sourceURL=external_%22iconv-lite%22");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"os\");\n\n//# sourceURL=external_%22os%22");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"path\");\n\n//# sourceURL=external_%22path%22");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"stream\");\n\n//# sourceURL=external_%22stream%22");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"url\");\n\n//# sourceURL=external_%22url%22");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"util\");\n\n//# sourceURL=external_%22util%22");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"zlib\");\n\n//# sourceURL=external_%22zlib%22");

/***/ })

/******/ })));